import java.io.File;
import java.util.List;

public class x {

	public static void main(String[] args) throws Exception {

	}

	private List<String> listJars() throws Exception {
		String file = "/home/admin/htao/target/htao.war/WEB-INF/lib";
		java.io.File f = new java.io.File(file);
		java.io.File[] files = f.listFiles();
		java.util.List<String> fileNames = new java.util.ArrayList<String>();
		if (files == null || files.length <= 0) {

		}

		String name = null;
		for (java.io.File item : files) {
			name = item.getName();

			if (name.endsWith(".jar")) {
				fileNames.add(name + "---" + size(item));
			}
		}
		java.util.Collections.sort(fileNames);
		return fileNames;
	}

	private int size(File f) throws Exception {
		byte[] bytes = null;
		java.io.FileInputStream in = null;
		try {
			in = new java.io.FileInputStream(f);
			return in.available();
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (Throwable e) {

				}
			}
		}
	}

}
