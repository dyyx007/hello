package htao;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;




public class jar {
	
	
	public static void main(String[] args) throws Exception {
		
	    String dir = "";
		File f = new File(dir);
		File[]fs = f.listFiles();
		String name = null;
		List<String> list = new ArrayList<String>();
		String matchName = "trade";
		if(matchName==null){
			matchName = "";
		}
		matchName = matchName.trim();
		
		for(File item:fs){
			name = item.getName();
			
			if(   matchName.length()<=0  ||  name.indexOf(matchName)>=0){
				list.add(name);
			}
		}
		Collections.sort(list);
		
		//list;
		
		//return list;
		
		
		
	}
	
	
  
}
