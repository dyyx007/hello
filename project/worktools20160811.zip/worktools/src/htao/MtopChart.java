package htao;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.DateTickUnit;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.time.Day;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;

import util.HtaoCommUtil;


public class MtopChart {
	
	private static String srcFile = "d:/dugang/htao/project/20151015-mtop-detail/final-data.txt";
	private static String destFile = "d:/mtop.jpg";

	private static String SEP = "|";
	
	private static int tickCount = 30;
	
	private static final String DATE_FORMAT = "yyyy-MM-dd";
	
	public static void main(String[] args) throws Exception {
		System.out.println("mtop chart");
       

		//TimeSeries times = new TimeSeries("time");
		TimeSeries pvs = new TimeSeries("pv");
		TimeSeries xysjs = new TimeSeries("response time");
		
		
		// add data
		List<String> lines = HtaoCommUtil.readLines(srcFile);
		if(lines==null || lines.isEmpty()){
			System.out.println("lines empty");
			return;
		}
		Date time = null;
		Double pv = null;
		Double xysj = null;
		double pv2 = 0;
		for(String line:lines){
			if(HtaoCommUtil.isblank(line)){
				continue;
			}
			List<String> list = HtaoCommUtil.split(line, SEP);
			if(list==null){
				continue;
			}
			int len = list.size();
			if(len!=3){
				continue;
			}
			time = HtaoCommUtil.getDate(list.get(0),DATE_FORMAT,null);
			if(time==null){
				continue;
			}
		    pv = HtaoCommUtil.getDouble(list.get(1), 0);
		    if(pv==null || pv<=0){
		    	continue;
		    }
		    xysj = HtaoCommUtil.getDouble(list.get(2), 0);
		    if(xysj==null || xysj<=0){
		    	continue;
		    }
		    pv2 = pv / 10000;
		    pv2= HtaoCommUtil.format(pv2,"0.##");
		    
		    pvs.add(new Day(time), pv2);
		    xysjs.add(new Day(time),xysj);
		    
		}
		
		
		TimeSeriesCollection dataset = new TimeSeriesCollection();
		//dataset.addSeries(times);
		dataset.addSeries(pvs);
		dataset.addSeries(xysjs);
		
        String title = "h5 detail mtop api pv and response time";
        String xlabel = "time";
        String ylabel = "pv and response time";
		JFreeChart chart = ChartFactory.createTimeSeriesChart(title, xlabel, ylabel, dataset, true, true, false);

		XYPlot xyplot = (XYPlot) chart.getPlot();
		DateAxis domainAxis = (DateAxis) xyplot.getDomainAxis();

		System.out.println("tickCount=" + tickCount);

		domainAxis.setTickUnit(new DateTickUnit(DateTickUnit.DAY, tickCount, new SimpleDateFormat(DATE_FORMAT)));
		domainAxis.setVerticalTickLabels(true);
		//domainAxis.setLabelAngle(45);
		//domainAxis.setDateLabelPositions(CategoryLabelPositions.DOWN_45);

		// customise the range axis...
		NumberAxis rangeAxis = (NumberAxis) xyplot.getRangeAxis();
		//rangeAxis.setVerticalTickLabels(true);
		//rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());

		//rangeAxis.setAutoRange(true);

		//rangeAxis.setAutoRangeMinimumSize(3500);
		//if (up > 0 && low >= 0) {
		//	rangeAxis.setRange(low, up);
		//}

		// Output
		File outputFile = new File(destFile);
		ChartUtilities.saveChartAsPNG(outputFile, chart, 900, 600);

		System.out.println("mtop chart done");
		
	}



}
