package htao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import util.HtaoCommUtil;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;



public class HarParse {
	
   private static final String FILE = HtaoCommUtil.WORK_DIR + "detail-har.txt";
	public static void main(String[] args) throws Exception {
		
		System.out.println("har parse");
		String str = HtaoCommUtil.readString(FILE, "utf-8");
		//System.out.println(str);
		JSONObject obj = JSON.parseObject(str);
		obj = obj.getJSONObject("log");
		JSONArray arr = obj.getJSONArray("entries");
		int size = arr.size();
		System.out.println(size);
		List<String> urls = new ArrayList<String>();
		String url = null;
		for(int i=0;i<size;i++){
			obj = arr.getJSONObject(i);
			obj = obj.getJSONObject("request");
			url = obj.getString("url");
			urls.add(url);
			
			//System.out.println(url);
		}
		Collections.sort(urls);
		url = "http://img.alicdn.com/imgextra/";
		String domain = getDomain(url);
		System.out.println(domain);
		
		Set<String> domains = new HashSet<String>();
		
	
		for(String item:urls){
			
			System.out.println(item);
			domain = getDomain(item);
			if(!HtaoCommUtil.isblank(domain)){
				domains.add(domain);
			}
		}
		
		List<String> domainList = new ArrayList<String>();
		domainList.addAll(domains);
		Collections.sort(domainList);
		
		System.out.println("///////////");
		for(String item:domainList){
			System.out.println(item);
		}
		
		
		
	}

    private static String  getDomain(String url){
    	if(HtaoCommUtil.isblank(url)){
    		return null;
    	}
    	int start = url.indexOf("://");
    	int end = url.indexOf("/",start+4);
    	if(start<0){
    		return null;
    	}
    	if(end<=start){
    		return null;
    	}
    	return url.substring(start+3, end);
    }

}
