package htao;

import java.util.Date;

import util.HtaoCommUtil;




public class Time {
	
    private static final long ONE_MINUTE =  60L*1000L;
    private static final long ONE_HOUR =  ONE_MINUTE*60L;
	
    
    private static final String HEART_BEAT_CONFIG_KEY_PREFIX = "htao_heart_beat_";
    
    
	
	public static void main(String[] args) throws Exception {
		
		
		System.out.println("ONE_MINUTE="+ONE_MINUTE);
		System.out.println("ONE_HOUR="+ONE_HOUR);
		System.out.println("10hour="+ONE_HOUR *10L);
		System.out.println("20hour="+ONE_HOUR *20L);
		
		System.out.println("14hour="+ONE_HOUR *14L);
		
		
		
		
		Date start = new Date(1450108800000L);
		Date end = new Date( 1450713600000L);
		
		System.out.println("start="+start);
		System.out.println("end="+end);
		String s = "htao_heart_beat_30.10.210.60";
		s = getActiveHost( s);
		System.out.println(s);
		
		System.out.println(new Date(1399471681000L));
		
		System.out.println(new Date(1358474277000L));
		System.out.println(new Date(1398138053000L));
		
		
		
		
		
	}
	
	
	private static String getActiveHost(String s){
		if(HtaoCommUtil.isblank(s)){
			return null;
		}
		if(!s.startsWith(HEART_BEAT_CONFIG_KEY_PREFIX)){
			return null;
		}
		int index = s.indexOf(HEART_BEAT_CONFIG_KEY_PREFIX);
		if(index<0){
			return null;
		}
		return s.substring(index+HEART_BEAT_CONFIG_KEY_PREFIX.length());
	}

  
}
