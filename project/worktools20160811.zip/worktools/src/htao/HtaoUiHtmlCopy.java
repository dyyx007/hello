package htao;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import util.HtaoCommUtil;

public class HtaoUiHtmlCopy {

	private static String srcFile = "c:/www/htdocs/tb-htao/biz/";
	private static String destFile = "c:/www/htdocs/";
	private static final String HTML = ".html";

	public static void main(String[] args) throws Exception {
        File dir = new File(srcFile);
		List<File> list = new ArrayList<File>();
		getFiles( dir,list);
		
		System.out.println(list.size());
		File destFileObj = null; 
		for(File item:list){
			//System.out.println(item);
			destFileObj  = getDestFile(item);
		    if(destFileObj==null){
		    	continue;
		    }
		    copy(item,destFileObj);
		}
		//File f = new File(srcFile+"/address/new-addr.html");
		//copy(f,null);
		//File ff = getDestFile(f);
		
		System.out.println(list.size()+" html files copy done.");
		
	}
	
	private static void getFiles(File dir,List<File> list){
		if(dir==null || list==null){
			return;
		}
		if(!dir.isDirectory()){
			return;
		}
		File[]fs = dir.listFiles();
		if(fs==null || fs.length<=0){
			return;
		}
		String name = null;
		for(File item:fs){
			if(item==null){
				continue;
			}
			if(item.isDirectory()){
				
				getFiles(item,list);
				continue;
			}
			
			if(!item.isFile()){
				continue;
			}
			name = item.getName();
			if(HtaoCommUtil.isblank(name)){
				continue;
			}
			if(name.toLowerCase().endsWith(HTML)){
				list.add(item);
			}	
		}
		
	
			
	}
	
	private static void copy(File src,File dest)throws Exception{
		//System.out.println(src.getPath());
		//System.out.println(src.getName());
		///System.out.println(src.getAbsolutePath());
		byte[]bytes = HtaoCommUtil.readBytes(src);
		File destp=dest.getParentFile();
		if(!destp.exists()){
			destp.mkdirs();
		}
		HtaoCommUtil.write(bytes, dest);
	}
	
	private static File getDestFile(File src){
		String path = src.getAbsolutePath();
		int pos = path.indexOf("biz");
		if(pos<=0){
			return null;
		}
		String subpath = path.substring(pos+3);
		//System.out.println(subpath);
		
		return new File(destFile+subpath);
	}

}
