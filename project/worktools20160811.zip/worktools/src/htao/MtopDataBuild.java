package htao;

import java.util.ArrayList;
import java.util.List;

import util.HtaoCommUtil;

public class MtopDataBuild {
	
	private static String srcFile = "d:/dugang/htao/project/20151015-mtop-detail/raw-data.txt";
	private static String destFile = "";

	private static String SEP = "|";
	
	private static final String END = ")";
	
	public static void main(String[] args) throws Exception {
		System.out.println("mtop data build");
        String str = "categories.push('2014-11-01')";
        String start = "categories.push('";
        String end = ")";
        str = getString( str, start, end);
        System.out.println("str="+str);
        
        //
        List<String> lines = HtaoCommUtil.readLines(srcFile);
        List<String> times = new ArrayList<String>();
        List<Double> pvs = new ArrayList<Double>();
        List<Double> xysjs = new ArrayList<Double>();
        
        String time = null;
        Double pv = null;
        Double xysj = null;
        
        if(lines==null || lines.isEmpty()){
        	System.out.println("lines empty");
        	return;
        }
        
        for(String line:lines){
        	time = getTime(line);
        	pv = getPV(line);
        	xysj = getXysj(line);
        	if(!HtaoCommUtil.isblank(time)){
        		times.add(time);
        	}
        	if(pv!=null && pv>=0){
        		pvs.add(pv);
        	}
        	if(xysj!=null && xysj>=0){
        		xysjs.add(xysj);
        	}
        }
        
       
        
        int timeSize = times.size();
        int pvSize = pvs.size();
        int xysjSize = xysjs.size();
        
        System.out.println("times.size="+timeSize);
        System.out.println("pvs.size="+pvSize);
        System.out.println("xysjs.size="+xysjSize);
        
        
        if(pvSize!=timeSize || xysjSize!=timeSize){
        	System.out.println("size error");
        	return;
        }
        
        String line = null;
        for(int i=0;i<timeSize;i++){
        	line = times.get(i)+SEP+pvs.get(i)+SEP+xysjs.get(i);
        	System.out.println(line);
        }
        
        
	}

	private static String getTime(String str){
		// categories.push('2015-10-13');
		String start = "categories.push('";
		return getString(str, start,END);
	}
	
	private static Double getPV(String str){
		// qing_qiu_zcs.push( 0 );
		String start = "qing_qiu_zcs.push(";
		return getDoubleValue(str, start);
	}
	
	private static Double getXysj(String str){
		// ping_jun_xysj.push( 0 );
		String start = "ping_jun_xysj.push(";
		return getDoubleValue(str, start);
	}
	
	
	private static Double getDoubleValue(String str,String start){
		String tmp =  getString( str, start,END);
		if(HtaoCommUtil.isblank(tmp)){
			return null;
		}
		double v = HtaoCommUtil.getDouble(tmp, -1);
		if(v<0){
			return null;
		}
		return v;
	}
	
	private static String getString(String str,String start,String end){
		if(HtaoCommUtil.isblank(str)){
			return null;
		}
		if(HtaoCommUtil.isblank(start)){
			return null;
		}
		if(HtaoCommUtil.isblank(end)){
			return null;
		}
		
		int startIndex = str.indexOf(start);
		int endIndex = str.indexOf(end);
		if(startIndex<0 || endIndex <=0 || endIndex<=startIndex){
			return null;
		}
		String tmp = str.substring(startIndex+start.length(), endIndex-1);
		if(HtaoCommUtil.isblank(tmp)){
			return null;
		}
		tmp = tmp.trim();
		return tmp;
		
	}


}
