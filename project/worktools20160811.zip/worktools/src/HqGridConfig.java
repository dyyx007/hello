
public class HqGridConfig {
    public String code;
    public double low;
    public double high;
    public double lp;
    public double hp;
    public int count;
    
    public String toString(){
    	StringBuilder sb = new StringBuilder();
    	 sb.append("code"+code);
    	 sb.append(",low"+low);
    	 sb.append(",high"+high);
    	 sb.append(",lp"+lp);
    	 sb.append(",hp"+hp);
    	 sb.append(",count"+count);
    	return sb.toString();
    }
}
