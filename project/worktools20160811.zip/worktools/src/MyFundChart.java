import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

public class MyFundChart {

	private static final String DATA_FILE = "d:/dugang/workfun/daily-data.txt";

	private static final String EMPTY = "";

	private static final double DIF = 50;

	private static double min = 0;
	private static double max = 0;
	private static double low = 0;
	private static double up = 0;

	private static int winCount = 0;
	private static int lostCount = 0;

	private static int winVsIndexCount = 0;
	private static int lostVsIndexCount = 0;

	private static double winRate = 0;
	private static double aqi = 0;
	private static String info = null;
	private static String title = "AQI VS HS300 ";

	private static double nv0 = 0;
	private static double nv = 0;

	public static void main(String[] args) throws Exception {
		System.out.println("hello my chart");

		//ChartUtilities.saveChartAsPNG
		//ChartUtilities.saveChartAsPNG(new File("d:/xxx.jpg"), chart, 550, 250); 

		Map<String, String> argMap = getArgMap(args);
		System.out.println("argMap=" + argMap);

		String start = null;
		String showshape = null;

		if (argMap != null) {
			start = argMap.get("start");
			showshape = argMap.get("showshape");
		}
		boolean showShape = false;
		if ("1".equals(showshape)) {
			showShape = true;
		}
		System.out.println("showShape=" + showShape);
		List<DataDTO> list = readData();

		list = getDataList(list, start);

		std(list);

		if (list != null) {
			System.out.println("data num " + list.size());
			for (DataDTO item : list) {
				System.out.println(item);
			}
		}

		winAndLostCount(list);

		JFreeChart chart = createChart(createDataset(list), showShape);
		String file = "d:/aqi.jpg";
		int width = 800;
		int height = 600;
		ChartUtilities.saveChartAsJPEG(new File(file), chart, width, height);

		System.out.println("my fund chart  done!" + System.currentTimeMillis());
		System.out.println(title);
		//

	}

	private static void winAndLostCount(List<DataDTO> list) {
		int num = 0;
		if (list != null) {
			num = list.size();
		}
		if (num <= 1) {
			return;
		}
		//
		DataDTO pre;
		DataDTO current;

		double nvindexdif = 0;
		double hs300indexdif = 0;

		for (int i = 1; i < num; i++) {
			current = list.get(i);
			pre = list.get(i - 1);

			if (current == null || pre == null) {
				continue;
			}

			if (current.nv > pre.nv) {
				winCount++;
			} else {
				lostCount++;
			}

			nvindexdif = current.nvindex - pre.nvindex;
			hs300indexdif = current.hs300index - pre.hs300index;

			if (nvindexdif > hs300indexdif) {
				winVsIndexCount++;
			} else {
				lostVsIndexCount++;
			}
		}

		if (winCount <= 0 || lostCount <= 0) {
			return;
		}
		winRate = winCount * 100.0 / (winCount + lostCount);
		DataDTO first = list.get(0);
		DataDTO last = list.get(num - 1);
		aqi = last.nvindex;

		nv0 = first.nv;
		nv = last.nv;

		double profit = (nv - nv0) * 100.0 / nv0;

		title = title + " \n  win=" + winCount + ",lost=" + lostCount + ",win%=" + format(winRate) + "%,aqi=" + aqi;
		title = title + ",p=" + format(profit) + "%";

	}

	private static List<DataDTO> getDataList(List<DataDTO> list, String start) {
		if (list == null || list.isEmpty() || isblank(start)) {
			return list;
		}
		int startindex = 0;
		int num = list.size();
		for (int i = 0; i < num; i++) {
			if (start.equals(list.get(i).time)) {
				startindex = i;
				break;
			}
		}

		System.out.println("startindex=" + startindex + ",start=" + start);

		List<DataDTO> listnew = new ArrayList<DataDTO>();
		for (int i = startindex; i < num; i++) {
			listnew.add(list.get(i));
		}

		return listnew;
	}

	private static Map<String, String> getArgMap(String[] args) {
		if (args == null) {
			System.out.println("args is null");
			return null;
		}
		int num = args.length;
		System.out.println("args num " + num);
		String str = args[0];
		return getArgMap(str);
	}

	private static Map<String, String> getArgMap(String str) {
		// a=1#b=2
		Map<String, String> m = new HashMap<String, String>();
		if (isblank(str)) {
			return m;
		}
		String[] arr = str.split("#");
		if (arr == null || arr.length <= 0) {
			return m;
		}
		String[] arr2 = null;
		String key, value;
		for (String item : arr) {
			arr2 = item.split("=");
			if (arr2 == null || arr2.length != 2) {
				continue;
			}
			key = arr2[0];
			value = arr2[1];
			if (isblank(key) || isblank(value)) {
				continue;
			}
			key = key.trim();
			value = value.trim();
			m.put(key, value);
		}
		return m;
	}

	private static CategoryDataset createDataset(List<DataDTO> list) throws Exception {

		DefaultCategoryDataset dataset = new DefaultCategoryDataset();

		if (list == null || list.isEmpty()) {
			return dataset;
		}

		String hs300indexType = "hs300";
		String aqiindexType = "aqi";

		double nvindex = 0;
		double hs300index = 0;
		String time = null;

		for (DataDTO item : list) {
			if (item == null) {
				continue;
			}
			time = item.time;
			nvindex = item.nvindex;
			hs300index = item.hs300index;
			if (isblank(time)) {
				continue;
			}
			if (nvindex <= 0) {
				continue;
			}
			if (hs300index <= 0) {
				continue;
			}
			//dataset.addValue(nvindex, aqiindexType, time);
			//dataset.addValue(hs300index, hs300indexType, time);

			addValue(dataset, nvindex, aqiindexType, time);
			addValue(dataset, hs300index, hs300indexType, time);
		}

		if (max > 0) {
			up = max + DIF;
			low = min - DIF;
			if (low < 0) {
				low = 0;
			}
		}

		System.out.println("min=" + min + ",max=" + max);
		System.out.println("low=" + low + ",up=" + up);

		return dataset;

	}

	private static void addValue(DefaultCategoryDataset ds, double value, Comparable rowKey, Comparable columnKey) {
		if (value <= 0) {
			return;
		}
		ds.addValue(value, rowKey, columnKey);

		if (min <= 0) {
			min = value;
			max = value;
			return;
		}
		if (value < min) {
			min = value;
		}
		if (value > max) {
			max = value;
		}

	}

	private static void std(List<DataDTO> list) throws Exception {
		if (list == null || list.isEmpty()) {
			return;
		}
		double nv;
		double hs300index;

		DataDTO dto = list.get(0);
		if (dto == null) {
			return;
		}
		nv = dto.nv;
		hs300index = dto.hs300index;

		if (nv <= 0) {
			return;
		}

		if (hs300index <= 0) {
			return;
		}
		double f = hs300index / nv;
		double nvindex = 0;
		for (DataDTO item : list) {
			nv = item.nv;
			if (nv <= 0) {
				continue;
			}
			hs300index = dto.hs300index;
			if (hs300index <= 0) {
				continue;
			}
			nvindex = nv * f;
			nvindex = format(nvindex);
			if (nvindex <= 0) {
				continue;
			}
			item.nvindex = nvindex;

		}
	}

	private static JFreeChart createChart(CategoryDataset dataset, boolean showshape) {

		// create the chart...
		JFreeChart chart = ChartFactory.createLineChart(title, // chart title
				"time", // domain axis label
				"index", // range axis label
				dataset, // data
				PlotOrientation.VERTICAL, // orientation
				true, // include legend
				true, // tooltips
				false // urls
				);

		chart.setBackgroundPaint(Color.white);

		CategoryPlot plot = (CategoryPlot) chart.getPlot();
		plot.setBackgroundPaint(Color.lightGray);
		plot.setRangeGridlinePaint(Color.white);

		CategoryItemRenderer render = plot.getRenderer();
		boolean showValues = false;

		if (render != null && showValues) {
			// show values
			render.setBaseItemLabelsVisible(true);
			render.setBaseItemLabelGenerator(new StandardCategoryItemLabelGenerator());
		}

		// customise the range axis...
		NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
		//rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());

		//rangeAxis.setAutoRange(true);

		//rangeAxis.setAutoRangeMinimumSize(3500);
		if (up > 0) {
			rangeAxis.setRange(low, up);
		}

		//rangeAxis.setLowerBound(3500);

		CategoryAxis caxis = plot.getDomainAxis();
		caxis.setCategoryLabelPositions(CategoryLabelPositions.DOWN_45);
		//caxis.setCategoryMargin(0.2);
		//caxis.setMinorTickMarkInsideLength(1);
		//caxis.setMaximumCategoryLabelLines(lines)
		caxis.setTickLabelsVisible(false);

		// customise the renderer...
		LineAndShapeRenderer renderer = (LineAndShapeRenderer) plot.getRenderer();
		if (showshape) {
			renderer.setSeriesShapesVisible(0, true);
			renderer.setSeriesShapesVisible(1, true);
		}

		//renderer.setSeriesShapesVisible(2, true);
		//renderer.setSeriesLinesVisible(2, false);
		//renderer.setSeriesShape(2, ShapeUtilities.createDiamond(4.0f));
		//renderer.setDrawOutlines(true);
		//renderer.setUseFillPaint(true);
		//renderer.setFillPaint(Color.white);

		return chart;

	}

	private static List<DataDTO> readData() throws Exception {
		List<DataDTO> list = new ArrayList<DataDTO>();

		List<String> lines = readLines(DATA_FILE);
		if (lines == null || lines.isEmpty()) {
			return list;
		}

		String[] arr = null;
		String time;
		String nvstr;
		String hs300indexstr;
		double nv = 0;
		double hs300index = 0;
		double nvindex = 0;

		DataDTO dto;
		for (String line : lines) {
			if (line == null) {
				continue;
			}
			line = line.trim();
			if (line.length() <= 0) {
				continue;
			}
			arr = line.split("\\|");
			if (arr == null || arr.length < 3) {
				continue;
			}
			time = arr[0];
			nvstr = arr[1];
			hs300indexstr = arr[2];

			if (isblank(time)) {
				continue;
			}
			if (isblank(nvstr)) {
				continue;
			}
			if (isblank(hs300indexstr)) {
				continue;
			}
			time = time.trim();
			nvstr = nvstr.trim();
			hs300indexstr = hs300indexstr.trim();

			nv = getDouble(nvstr);
			hs300index = getDouble(hs300indexstr);

			if (nv <= 0) {
				continue;
			}
			if (hs300index <= 0) {
				continue;
			}

			dto = new DataDTO();

			dto.time = time;
			dto.nv = nv;
			dto.hs300index = hs300index;

			list.add(dto);
		}

		return list;
	}

	private static List<String> readLines(String file) throws Exception {
		List<String> list = new ArrayList<String>();
		BufferedReader br = null;

		//InputStream is = new FileInputStreamReader(file);
		//InputStream is = new FileInputStream(new File(file));  

		br = new BufferedReader(new FileReader(file));
		String line = null;
		while ((line = br.readLine()) != null) {
			if (isblank(line)) {
				continue;
			}
			line = line.trim();
			list.add(line);
		}
		br.close();
		return list;
	}

	private static boolean isblank(String str) {
		if (str == null || EMPTY.equals(str)) {
			return true;
		}
		String tmp = str.trim();
		if (tmp.length() <= 0) {
			return true;
		}
		return false;
	}

	private static double getDouble(String str) {
		try {
			return Double.parseDouble(str);
		} catch (Throwable e) {
			return 0;
		}
	}

	private static double format(double v) {
		DecimalFormat df = new DecimalFormat("0.##");
		String str = df.format(v);
		return getDouble(str);
	}

}
