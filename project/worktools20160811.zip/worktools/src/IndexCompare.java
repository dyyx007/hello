import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



public class IndexCompare {

	private static final String DATE_FORMAT = "yyyy-MM-dd";
	
	
	private static int xLableNum = 20;
	private static int tickCount = 5;
	private static int num = 0;

	

	private static Map<String, String> map = null;

	
	public static void main(String[] args) throws Exception {
		
		
		map = CommUtil.getArgMap(args);
		if (map == null) {
			map = new HashMap<String, String>();
		}
		//a=1#b=2
		String xLableNumStr = map.get("xnum");
		int xLableNumTmp = CommUtil.getInt(xLableNumStr);
		if (xLableNumTmp > 2) {
			xLableNum = xLableNumTmp;
		}
		String file = "D:/dugang/workfun/data/000016.csv";
		
		List<IndexDataDTO> list = getIndexDataDTOs( file,"gbk");
		Collections.sort(list);
		for(IndexDataDTO dto:list){
			System.out.println(dto);
		}
	
	}
	
	private static IndexDataDTO getIndexDataDTO(String str){
		if(CommUtil.isblank(str)){
			return null;
		}
		str = str.trim();
		// 2015-09-10,'000016,SZ50,2208.481
		List<String> list = CommUtil.split(str, ",");
		int num = list.size();
		if(num<4){
			return null;
		}
		String timestr = list.get(0);
		String code = list.get(1);
		String name = list.get(2);
		String value = list.get(3);
		Date time = CommUtil.getDate(timestr,DATE_FORMAT,null);
		if(time==null){
			return null;
		}
		if(CommUtil.isblank(code)){
			return null;
		}
		if(CommUtil.isblank(name)){
			return null;
		}
		
		int len = code.length();
		if(len>6){
			code = code.substring(len-6);
		}
		double v = CommUtil.getDouble(value, 0);
		if(v<=0){
			return null;
		}
		
		IndexDataDTO dto = new IndexDataDTO();
		dto.timestr = timestr;
		dto.time = time;
		dto.code = code;
		dto.name = name;
		dto.value = v;
		
		return dto;
	}
	
	private static List<IndexDataDTO> getIndexDataDTOs(String file,String charset)throws Exception{
		List<String> lines = CommUtil.readLines(file, charset);
		if(lines==null || lines.isEmpty()){
			return null;
		}
		List<IndexDataDTO> list = new ArrayList<IndexDataDTO>();
		IndexDataDTO dto = null;
		for(String line:lines){
			dto = getIndexDataDTO( line);
			if(dto==null){
				continue;
			}
			list.add(dto);
		}
		
		return list;
	}
	

}
