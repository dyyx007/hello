import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.DateTickUnit;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.time.Day;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;



public class MaAndBias {

	private static final String DATE_FORMAT = "yyyy-MM-dd";
	
	
	private static int xLableNum = 20;
	private static int tickCount = 5;
	private static int num = 0;

	//private static int totalDataNum = 0;
	//private static int chartDataNum = 0;
	//private static String start = null;

	private static Map<String, String> map = null;

	
	public static void main(String[] args) throws Exception {
		
		
		map = CommUtil.getArgMap(args);
		if (map == null) {
			map = new HashMap<String, String>();
		}
		//a=1#b=2
		String xLableNumStr = map.get("xnum");
		int xLableNumTmp = CommUtil.getInt(xLableNumStr);
		if (xLableNumTmp > 2) {
			xLableNum = xLableNumTmp;
		}
		
		
		
		String file = "d:/dugang/workfun/data/000001-2.txt";
		List<MaAndBiasDataDTO> dtos = getDataDTOs( file);
		num = dtos.size();
		//System.out.println(dtos.size());
		Collections.sort(dtos);
		
		
		if (num > xLableNum) {
			tickCount = num / xLableNum;
		}
		if (tickCount <= 0) {
			tickCount = 1;
		}
		
		List<Integer> periods = new ArrayList<Integer>();
		//periods.add(5);
		//periods.add(10);
		//periods.add(20);
		//periods.add(30);
		//periods.add(60);
		periods.add(120);
		periods.add(250);
		periods.add(500);
		periods.add(1000);
		periods.add(2000);
		//build(dtos,250);
		for(Integer period:periods){
			build(dtos,period);
		}
		
		
		
		
		for(MaAndBiasDataDTO dto:dtos){
			System.out.println(dto);
		}
		
		

		TimeSeriesCollection dataset = new TimeSeriesCollection();


		for(Integer period:periods){
			TimeSeries ts = buildMaTimeSeries(dtos, period);
			//TimeSeries ts = buildBiasTimeSeries(dtos, period);
			if(ts==null){
				continue;
			}
			dataset.addSeries(ts);
		}
		TimeSeries indexts = new TimeSeries("index");
		for(MaAndBiasDataDTO dto:dtos){
		
			indexts.add(new Day(dto.time),dto.value);
		}
		dataset.addSeries(indexts);
		
		
        String title = "";
        String xlabel = "";
        String ylabel = "";
		JFreeChart chart = ChartFactory.createTimeSeriesChart(title, xlabel, ylabel, dataset, true, true, false);

		XYPlot xyplot = (XYPlot) chart.getPlot();
		DateAxis domainAxis = (DateAxis) xyplot.getDomainAxis();

		System.out.println("tickCount=" + tickCount);

		domainAxis.setTickUnit(new DateTickUnit(DateTickUnit.DAY, tickCount, new SimpleDateFormat("yyyy-MM-dd")));
		domainAxis.setVerticalTickLabels(true);
		//domainAxis.setLabelAngle(45);
		//domainAxis.setDateLabelPositions(CategoryLabelPositions.DOWN_45);

	
		ValueAxis valueaxis = xyplot.getRangeAxis();
		//valueaxis.setRange(-100.0, 200);
		//valueaxis.setAutoRange(false);
		

		// Output
		File outputFile = new File("d:/ma.jpg");
		ChartUtilities.saveChartAsPNG(outputFile, chart, CommUtil.width, CommUtil.height_pv);

		System.out.println("ma chart done");
		
		
		
		
		
	}
	
	private static TimeSeries buildMaTimeSeries(List<MaAndBiasDataDTO> list,int period){
		TimeSeries ts = new TimeSeries("MA"+period);
        if(list==null || list.isEmpty()){
        	return ts;
        }
        Double value;
		for(MaAndBiasDataDTO dto:list){
			
			value = dto.getMaData(period);
			if(value==null || value<=0){
				continue;
			}
			ts.add(new Day(dto.time),value);
		}
		return ts;
	}
	
	private static TimeSeries buildBiasTimeSeries(List<MaAndBiasDataDTO> list,int period){
		TimeSeries ts = new TimeSeries("BIAS"+period);
        if(list==null || list.isEmpty()){
        	return ts;
        }
        Double value;
		for(MaAndBiasDataDTO dto:list){
			
			value = dto.getBiasData(period);
			//System.out.println("bias-value-"+period+","+value+","+dto.timestr);
			//if(value==null || value<=0){
			//	continue;
			//}
			ts.add(new Day(dto.time),value);
		}
		return ts;
	}
	
	
	private static void build(List<MaAndBiasDataDTO> list,int period){
		if(list==null || list.isEmpty()){
			return;
		}
		int size = list.size();
		if(period < MaAndBiasDataDTO.MIN_PERIOD || period > size){
			return;
		}
		// 5
		// 0 1 2 3 4 5 6 7
		// - - - - a b c d 
		int start = period-1;
		double sum = 0;
		double avg = 0;
		double bias = 0;
		double value = 0;
		MaAndBiasDataDTO dto = null;
		for(int i=start;i<size;i++){
			
			dto = list.get(i);
			value= dto.value;
			sum = sum(list,period,i);
			
			avg = sum/period;			
			bias = (value-avg) * 100.0/avg;
			
			avg = CommUtil.format(avg, "0.##");
			bias = CommUtil.format(bias, "0.##");
			
			dto.addMaData(period, avg);
			dto.addBiasData(period, bias);
		}
		
		
	}
	
	private static double sum(List<MaAndBiasDataDTO> list,int count,int endIndex){
		int startIndex = endIndex +1 - count ;
		double sum = 0;
		MaAndBiasDataDTO dto = null;
		for(int i=startIndex;i<=endIndex;i++){
			dto = list.get(i);
			sum=sum+dto.value;
		}
		return sum;
	}
	
	
	private static List<MaAndBiasDataDTO> getDataDTOs(String file)throws Exception{
		List<String> lines = CommUtil. readLines( file);
		if(lines==null || lines.isEmpty()){
			return null;
		}
		 List<MaAndBiasDataDTO> list = new ArrayList<MaAndBiasDataDTO>();
		 MaAndBiasDataDTO dto = null;
		 for(String line:lines){
			 dto = getDataDTO( line);
			 if(dto==null){
				 continue;
			 }
			 list.add(dto);
		 }
		 
		 return list;
		
	}
	
	private static MaAndBiasDataDTO getDataDTO(String str){
		if(CommUtil.isblank(str)){
			return null;
		}
		str= str.trim();
		List<String> list = CommUtil.split(str, ",");
		if(list==null || list.size() < 4){
			return null;
		}
		String timestr = list.get(0);
		String valuestr = list.get(3);

		if(CommUtil.isblank(timestr)){
			return null;
		}
		if(CommUtil.isblank(valuestr)){
			return null;
		}
		Date time = CommUtil.getDate(timestr, DATE_FORMAT);
		if(time==null){
			return null;
		}
		double value = CommUtil.getDouble(valuestr, 0);
		if(value<=0){
			return null;
		}
		MaAndBiasDataDTO dto = new MaAndBiasDataDTO();
		dto.timestr = timestr;
		dto.time = time;
		dto.value = value;
		return dto;
	}

	
}
