import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSON;

/**
 * @author gang.dug
 * @version 1.0.0 2015-10-29 ����6:53:57
 * @since JDK1.6
 */
public class Hq {

	private static final String START = "\"";
	private static final String END = "\"";
	private static final String EQ = "=";
	private static final String SEP = ",";
	private static final String FORMAT = "0.##";
	private static final String FORMAT2 = "0.###";
	private static final String LINE = "\n";
	
    private static final String LIST = "sh510050,sh510300,sh510900,sz159901,sz159915,sh000001,sh000016,sh000300,sz399001,sz399005,sz399006";
    
    private static final String SPACE = " ";
    //private static final String A     = "A";
    private static final String EMPTY = "";
    private static final String SEP2 = "|";

    
    private static final String HQ_CONFIG = "d:/dugang/workfun/hq-config.txt";
    
    private static String codes = LIST;
    
	public static void main(String[] args) throws Exception {
		// http://hq.sinajs.cn/rn=1446114865205&list=sh510300,sh510050,sh510180
		// http://hq.sinajs.cn/list=sh510050,sh510300,sh510900,sz159901,sz159915,sh000001,sh000016,sh000300,sz399001,sz399005,sz399006
		//���� ������ ���¼� ��߼� ��ͼ�  ��һ ��һ �ɽ��� �ɽ��� �����嵵 ����ʱ��
		//var hq_str_sh000300="����300,0.000,3533.307,3533.307,0.000,0.000,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2015-10-30,09:08:49,00";

		// var hq_str_sh510300="300ETF,3.582,3.579,3.584,3.620,3.558,3.584,3.585,121324456,435133941,649600,3.584,20600,3.583,5000,3.582,262400,3.581,13900,3.580,80400,3.585,2311000,3.586,42800,3.587,67300,3.588,5000,3.589,2015-10-29,15:04:10,00";

		//System.out.println("hq");
	
		
		//String url = "http://hq.sinajs.cn/rn=1446114865205&list=sh510300,sh510050,sh510180";
		
		//str =  CommUtil.doGet(url);
		
		HqConfig hqconfig =  readHqConfig();
		if(hqconfig!=null){
		   //System.out.println(JSON.toJSONString(hqconfig, true));
		}
		String configCodes = hqconfig.codes;
		if(!CommUtil.isblank(configCodes)){
			configCodes = configCodes.trim();
			codes = configCodes;
		}
		
		//System.out.println(str);
		List<HqData> dtos = readData();
		if(dtos==null || dtos.isEmpty()){
			System.out.println("no data");
			return ;
		}
		
		
		
		buildPosition(dtos,hqconfig);
		
		int size = dtos.size();
		//System.out.println("data size "+size);
		for(HqData item:dtos){
			//System.out.println(item);
		}
		//System.out.println("////////////");
		for(HqData item:dtos){
			//System.out.println(item);
			System.out.println(getInfo(item));
		}
	}
	
	private static void buildPosition(List<HqData> list,HqConfig hqconfig){
		if(list==null || list.isEmpty()){
			return;
		}
		if(hqconfig==null){
			return;
		}
		//
		List<HqGridConfig> grids = hqconfig.grids;
		if(grids==null || grids.isEmpty()){
			return;
		}
		//
		Map<String,HqGridConfig> gridMap = new HashMap<String,HqGridConfig>();
		for(HqGridConfig item:grids){
			if(item==null){
				continue;
			}
			String code = item.code;
			if(CommUtil.isblank(code)){
				throw new RuntimeException("grid config code is blank");
			}
		    double low = item.low;
		    double high = item.high;
		    double lp = item.lp;
		    double hp = item.hp;
		    
		    if(low<=0 || high<=0 || high<=low){
		    	throw new RuntimeException("grid config low and high error");
		    }
		    
		    if(lp<0){
		    	lp = 0;
		    	item.lp = lp;
		    }
		    if(hp<=0){
		    	hp=0.8;
		    	item.hp = hp;
		    }
		    
		    if(lp<0 || hp<=0 || hp<=lp){
		    	throw new RuntimeException("grid config low and high position error");
		    }
		    
		    gridMap.put(code, item);
		}
		
		for(HqData item:list){
			if(item==null){
				continue;
			}
			buildPosition(item,gridMap.get(item.code));
		}
		
	}
	
	private static void buildPosition(HqData data,HqGridConfig config){
		if(data==null || config==null){
			return;
		}
		//
		double now = data.now;
		if(now<=0){
			return;
		}
		double low = config.low;
	    double high = config.high;
	    double lp = config.lp;
	    double hp = config.hp;
	    
	    double position = CommUtil.getPosition(low, high, now, lp, hp);
	    
	    position =  CommUtil.format(position, "0.###");
		
	    data.position = position ;
	    
	    double fall =  (high-now) * 100.0 / high;
	    fall =  CommUtil.format(fall, "0.#");
	    data.fall = fall;
	    
	    
	}
	
	private static HqConfig readHqConfig()throws Exception{
		String str = CommUtil.readString(HQ_CONFIG, null);
		if(CommUtil.isblank(str)){
			return null;
		}
		return JSON.parseObject(str, HqConfig.class);
	}
	
	

	private static List<HqData> readData()throws Exception{
		String url = "http://hq.sinajs.cn/rn="+System.currentTimeMillis()+"&list="+codes;
		String result = CommUtil.doGet(url);
		//System.out.println(result);
		if(CommUtil.isblank(result)){
			return null;
		}
		List<String> lines = CommUtil.split(result, LINE);
		if(lines==null || lines.isEmpty()){
			return null;
		}
		List<HqData> dtos = new ArrayList<HqData>();
		HqData dto = null;
		for(String line:lines){
			if(CommUtil.isblank(line)){
				continue;
			}
			line = line.trim();
			dto =  getHqData(line);
			if(dto!=null){
				dtos.add(dto);
			}
		}

		return  dtos;
	}
	
	
	private static HqData getHqData(String str) {
		String code = getCode(str);
		if (CommUtil.isblank(code)) {
			return null;
		}
		String data = getData(str);
		if (CommUtil.isblank(data)) {
			return null;
		}
		HqData dto = new HqData();
		dto.code = code;

		List<String> list = CommUtil.split(data, SEP);

		if (list == null) {
			return null;
		}

		int size = list.size();
		//System.out.println("list size "+size);
		if (size < 33) {
			return null;
		}
		//System.out.println("list size "+list.size());
		String time = list.get(30) + " " + list.get(31);
		dto.time = time;

		// hq_str_sh510300="300ETF,3.577,3.584,3.575,3.579,3.568
		//name ���� ������ ���¼� ��߼� ��ͼ� 
		//
		String name = list.get(0);
		String open = list.get(1);
		String yclose = list.get(2);
		String now = list.get(3);
		String max = list.get(4);
		String min = list.get(5);
		
		double openv = getDouble(open);
		double yclosev = getDouble(yclose);
		double nowv = getDouble(now);
		double maxv = getDouble(max);
		double minv = getDouble(min);
		
		//openv = CommUtil.format(openv,FORMAT);
		//yclosev = CommUtil.format(yclosev,FORMAT);
		//nowv = CommUtil.format(nowv,FORMAT);
		//maxv = CommUtil.format(maxv,FORMAT);
		//minv = CommUtil.format(minv,FORMAT);
		
		dto.name = name;
		dto.open = openv;
		dto.yclose = yclosev;
		dto.now = nowv;
		dto.min = minv;
		dto.max = maxv;
		
		double delta = 0;
		double deltap = 0;
		if(yclosev >0 && nowv >0){
			delta = nowv-yclosev;
		
			
			deltap = delta * 100 / yclosev;
			
			delta = CommUtil.format(delta,FORMAT2);
			deltap = CommUtil.format(deltap,FORMAT);
			
			dto.delta = delta;
			dto.deltap = deltap;
		}
		
		if(minv>0&&maxv>0){
			double v = maxv-minv;
			double vp = v*100/yclosev;
			
			v = CommUtil.format(v,FORMAT2);
			vp = CommUtil.format(vp,FORMAT);
			
			dto.v = v;
			dto.vp = vp;
			
		}
		
		dto.buildFlag();

		return dto;
	}

	private static double getDouble(String str){
		double v = CommUtil.getDouble(str);
		if(v>1000){
			v = CommUtil.format(v, FORMAT);
		}
		return v;
	}
	
	
	private static String getData(String str) {
		if (CommUtil.isblank(str)) {
			return null;
		}
		str = str.trim();
		int start = str.indexOf(START);
		if (start <= 0) {
			return null;
		}
		int end = str.lastIndexOf(END);
		if (end <= start) {
			return null;
		}

		return str.substring(start + 1, end - 1);
	}

	private static String getCode(String str) {
		if (CommUtil.isblank(str)) {
			return null;
		}
		int end = str.indexOf(EQ);
		if (end <= 8) {
			return null;
		}

		return str.substring(end - 8, end);
	}
	
	/**
	 * һ�������ַ���2������
	 * @param str
	 * @return
	 */
	private static int getLen(String str){
		if(CommUtil.isblank(str)){
			return 0;
		}
		int len = str.length();
		int wchnum = 0;
		char ch = 0;
		for(int i=0;i<len;i++){
			ch = str.charAt(i);
			if(ch>256){
				wchnum++;
			}
		}	
		return len+wchnum;
	}
	
	private static String repeat(String str,int num){		
		if(str==null || num<=0){
			return EMPTY;
		}
		StringBuilder sb = new StringBuilder();
		
		for(int i=0;i<num;i++){
			sb.append(str);
		}
		return sb.toString();
	}
	
	/**
	 *  �ַ����ﲻ��ָ������lenʱ ��ĩβ�ÿո���� 
	 * @param str
	 * @param len
	 * @return
	 */
	private static String format(String str,int len){	
		if(len<=0){
			return str;
		}
		if(str==null){
			return repeat(SPACE,len);
		}
		int lentmp = getLen(str);
		//System.out.println(str+","+lentmp+","+len);
		if(lentmp>=len){
			return str;
		}
		int num = len - lentmp;
		//System.out.println(str+","+lentmp+","+len+","+num);
		if(num<=0){
			return str;
		}
		return str+repeat(SPACE,num);
	}
	

	public static String getInfo(HqData dto){
		if(dto==null){
			return null;
		}
		//System.out.println("getInfo-"+dto);
		StringBuilder sb = new StringBuilder();
		sb.append(format(dto.name+"_",10)).append(SEP2);
		sb.append(format(dto.now +"",9)).append(SEP2);
		sb.append(format(dto.flag,1)).append(SEP2);
		sb.append(format(dto.deltap +"",5)).append(SEP2);
		sb.append(format(dto.yclose +"",9)).append(SEP2);
		sb.append(format(dto.min +"",9)).append(SEP2);
		sb.append(format(dto.max +"",9)).append(SEP2);
		sb.append(format(dto.vp +"",5)).append(SEP2);
		sb.append(format(dto.position +"",5)).append(SEP2);
		sb.append(format(dto.fall +"",5)).append(SEP2);
		//sb.append(dto.time);
		return sb.toString();
	}

}
