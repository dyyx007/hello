import java.util.Date;

public class IndexDataDTO implements Comparable<IndexDataDTO> {

	public String timestr;
	public Date  time;
	
	// for single index start
	public double value;
	public String code;
	public String name;
	public double valuestd;
	

	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("time=" + time);
		sb.append(",timestr=" + timestr);
		
		sb.append(",code=" + code);
		sb.append(",name=" + name);
		sb.append(",value=" + value);
		
		sb.append(",valuestd=" + valuestd);
		
		
		return sb.toString();
	}
	
	public int compareTo(IndexDataDTO other) {
		if(other==null){
			return 1;
		}
		
		Date timeother = other.time;
		
		if(time==null && timeother==null){
			return 0;
		}
		if(time==null && timeother!=null){
			return -1;
		}
		if(time!=null && timeother==null){
			return 1;
		}
		
		return time.compareTo(timeother);
		
	}
}
