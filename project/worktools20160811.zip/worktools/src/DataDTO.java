import java.util.Date;

public class DataDTO {

	public String time;
	public double nv;
	public double nvindex;
	public double hs300index;
	public double rzye;
	public Date  timeDate;
	/**
	 *  ��λ �ֲ�
	 */
	public int position;
	// buy volume
	public int bv;
	// sell volume
	public int sv;
	//volume  v = bv + sv
	public int v;
	
	
	
	

	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("time=" + time);
		sb.append(",timeDate=" + timeDate);
		sb.append(",nv=" + nv);
		sb.append(",nvindex=" + nvindex);
		sb.append(",hs300index=" + hs300index);
		sb.append(",rzye=" + rzye);
		
		sb.append(",position=" + position);
		sb.append(",bv=" + bv);
		sb.append(",sv=" + sv);
		sb.append(",v=" + v);
		
		return sb.toString();
	}
}
