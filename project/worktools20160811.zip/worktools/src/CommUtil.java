import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CommUtil {

	
	
	
	public static int width = 800;
	public static int height = 600;
	public static int height_pv = 500;

	public static double min = 0.0000001;

	private static final String EMPTY = "";

	public static String BLANK = " ";

	private static final String DATE_FORMAT = "yyyyMMdd";

	public static final String DATA_FILE = "d:/dugang/workfun/daily-data.txt";
	public static final String DEST_FILE = "d:/aqi.jpg";
	//private static final double DIF = 50;
	public static final String CHARSET = "utf-8";

	public static final String SEP = "\\|";
	
	private static final String CHARSET_KEY = "charset=";
	private static final int CHARSET_KEY_LEN = CHARSET_KEY.length();

	public static void main(String[] args) throws Exception {

		System.out.println("comm util");
		String str = "20150819|950621|3886.14";
		DataDTO dto = getDataDTO(str);
		System.out.println(dto);

		str = "a,b,c";
		List<String> list = split(str, ",");
		System.out.println(join(list, ":"));

		str = "a,b,";
		list = split(str, ",");
		System.out.println(join(list, ":"));

		str = "a,,,b,";
		list = split(str, ",");
		System.out.println("list.size=" + list.size());
		System.out.println(join(list, ":"));
		
		str = "application/x-javascript; charset=GBK";
		
		String charset = getCharset(str);
		
		System.out.println("charset="+charset);

	}

	public static boolean isblank(String str) {
		if (str == null || EMPTY.equals(str)) {
			return true;
		}
		String tmp = str.trim();
		if (tmp.length() <= 0) {
			return true;
		}
		return false;
	}

	public static double getDouble(String str) {
		return getDouble(str, 0);
	}

	public static double getDouble(String str, double def) {
		if (isblank(str)) {
			return def;
		}
		str = str.trim();
		try {
			return Double.parseDouble(str);
		} catch (Throwable e) {
			return def;
		}
	}

	public static int getInt(String str) {
		return getInt(str, 0);
	}

	public static int getInt(String str, int def) {
		if (isblank(str)) {
			return def;
		}
		str = str.trim();
		try {
			return Integer.parseInt(str);
		} catch (Throwable e) {
			return def;
		}
	}

	public static double format(double v, String format) {
		DecimalFormat df = new DecimalFormat(format);
		String str = df.format(v);
		return getDouble(str);
	}

	public static double format(double v) {
		DecimalFormat df = new DecimalFormat("0.##");
		String str = df.format(v);
		return getDouble(str);
	}

	public static Map<String, String> getArgMap(String[] args) {

		Map<String, String> map = new HashMap<String, String>();

		if (args == null) {
			System.out.println("args is null");
			return map;
		}
		int num = args.length;
		System.out.println("args num " + num);
		String str = null;
		if (num > 0) {
			str = args[0];
		}
		return getArgMap(str);
	}

	public static Map<String, String> getArgMap(String str) {
		// a=1#b=2
		Map<String, String> m = new HashMap<String, String>();
		if (isblank(str)) {
			return m;
		}
		String[] arr = str.split("#");
		//String[] arr = split(str,"#");
		if (arr == null || arr.length <= 0) {
			return m;
		}
		String[] arr2 = null;
		String key, value;
		for (String item : arr) {
			arr2 = item.split("=");
			if (arr2 == null || arr2.length != 2) {
				continue;
			}
			key = arr2[0];
			value = arr2[1];
			if (isblank(key) || isblank(value)) {
				continue;
			}
			key = key.trim();
			value = value.trim();
			m.put(key, value);
		}
		return m;
	}

	public static List<DataDTO> readData(String file) throws Exception {
		List<DataDTO> list = new ArrayList<DataDTO>();

		List<String> lines = readLines(file);
		if (lines == null || lines.isEmpty()) {
			return list;
		}

		DataDTO dto = null;
		for (String line : lines) {
			if (line == null) {
				continue;
			}
			line = line.trim();
			if (line.length() <= 0) {
				continue;
			}

			dto = getDataDTO(line);
			if (dto == null) {
				continue;
			}

			list.add(dto);
		}

		return list;
	}

	public static Date getDate(String str, String format) {
		if (isblank(str)) {
			return null;
		}
		if (isblank(format)) {
			format = DATE_FORMAT;
		}
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			return sdf.parse(str);
		} catch (Throwable e) {
			throw new RuntimeException("getDate error,format=" + format + ",str=" + str, e);
		}
	}

	public static Date getDate(String str, String format, Date def) {
		try {
			return getDate(str, format);
		} catch (Throwable e) {
			return def;
		}
	}

	public static Date getDate(String str) {
		return getDate(str, null, null);
	}

	public static DataDTO getDataDTO(String str) {
		if (isblank(str)) {
			return null;
		}
		str = str.trim();

		String[] arr = null;
		String time;
		String nvstr;
		String hs300indexstr;
		double nv = 0;
		double hs300index = 0;
		Date timeDate = null;

		arr = str.split(SEP);
		if (arr == null || arr.length < 3) {
			return null;
		}
		time = arr[0];
		nvstr = arr[1];
		hs300indexstr = arr[2];

		int len = arr.length;

		if (isblank(time)) {
			return null;
		}
		if (isblank(nvstr)) {
			return null;
		}
		if (isblank(hs300indexstr)) {
			return null;
		}
		time = time.trim();
		nvstr = nvstr.trim();
		hs300indexstr = hs300indexstr.trim();

		timeDate = CommUtil.getDate(time);

		nv = getDouble(nvstr);
		hs300index = getDouble(hs300indexstr);

		if (nv <= 0) {
			return null;
		}
		if (hs300index <= 0) {
			return null;
		}

		if (timeDate == null) {
			return null;
		}

		String posstr;
		String bvstr;
		String svstr;
		int position = 0;
		int bv = 0;
		int sv = 0;

		if (len >= 4) {
			posstr = arr[3];

			posstr = posstr.trim();
			position = getInt(posstr, -1);
		}

		if (len >= 5) {
			bvstr = arr[4];
			bvstr = bvstr.trim();
			bv = getInt(bvstr, -1);
		}

		if (len >= 6) {
			svstr = arr[5];
			svstr = svstr.trim();
			sv = getInt(svstr, -1);
		}

		DataDTO dto = new DataDTO();

		dto.time = time;
		dto.timeDate = timeDate;
		dto.nv = nv;
		dto.hs300index = hs300index;

		if (position > 0) {
			dto.position = position;
		}
		if (bv > 0) {
			dto.bv = bv;
		}

		if (sv > 0) {
			dto.sv = sv;
		}

		return dto;

	}

	/**
	 * nvindex build
	 * 
	 * @param list
	 * @throws Exception
	 */
	public static void buildDataDTO(List<DataDTO> list) {
		if (list == null || list.isEmpty()) {
			return;
		}
		double nv;
		double hs300index;

		DataDTO dto = list.get(0);
		if (dto == null) {
			return;
		}
		nv = dto.nv;
		hs300index = dto.hs300index;

		if (nv <= 0) {
			return;
		}

		if (hs300index <= 0) {
			return;
		}
		double f = hs300index / nv;
		double nvindex = 0;

		Date time = null;
		Date timeDate = null;

		for (DataDTO item : list) {

			timeDate = item.timeDate;
			if (timeDate == null) {
				continue;
			}

			if (time == null) {
				//time = timeDate;
			} else {

				if (!timeDate.after(time)) {
					throw new RuntimeException("data time error,dto=" + item);
				}
				//time = timeDate;
			}
			time = timeDate;

			nv = item.nv;
			if (nv <= 0) {
				continue;
			}
			hs300index = item.hs300index;
			if (hs300index <= 0) {
				continue;
			}
			nvindex = nv * f;
			nvindex = format(nvindex);
			if (nvindex <= 0) {
				continue;
			}
			item.nvindex = nvindex;
		}
	}

	////////

	public static TradeDTO getTradeDTO(String str) {

		if (isblank(str)) {
			return null;
		}
		str = str.trim();

		String[] arr = null;
		String pricestr;
		String volumestr;

		arr = str.split(SEP);
		if (arr == null || arr.length < 2) {
			return null;
		}
		pricestr = arr[0];
		volumestr = arr[1];

		double price = getDouble(pricestr);
		if (price <= 0) {
			return null;
		}
		int volume = getInt(volumestr);
		if (volume <= 0) {
			return null;
		}
		TradeDTO dto = new TradeDTO();
		dto.price = price;
		dto.volume = volume;

		return dto;

	}

	/////  

	public static List<String> readLines(String file) throws Exception {
		return readLines(file, CHARSET);
	}

	public static List<String> readLines(String file, String charset) throws Exception {
		if (isblank(charset)) {
			charset = CHARSET;
		}
		List<String> list = new ArrayList<String>();
		BufferedReader br = null;

		//InputStream is = new FileInputStreamReader(file);
		//InputStream is = new FileInputStream(new File(file));  
		FileInputStream fis = null;

		try {

			fis = new FileInputStream(file);
			Reader reader = new InputStreamReader(fis, charset);
			br = new BufferedReader(reader);
			String line = null;
			while ((line = br.readLine()) != null) {
				if (isblank(line)) {
					continue;
				}
				line = line.trim();
				list.add(line);
			}

			return list;
		} finally {
			close(br);
			close(fis);

		}
	}

	public static byte[] readBytes(String file) throws Exception {

		InputStream is = null;
		byte[] buf = new byte[1024];
		int num = 0;
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		try {
			is = new FileInputStream(new File(file));

			while ((num = is.read(buf)) > 0) {

				bos.write(buf, 0, num);
			}

			return bos.toByteArray();

		} finally {
			close(is);
		}
	}

	public static String readString(String file, String charset) throws Exception {
		if (isblank(charset)) {
			charset = CHARSET;
		}
		byte[] bytes = readBytes(file);
		if (bytes == null || bytes.length <= 0) {
			return null;
		}
		return new String(bytes, charset);
	}

	public static void close(Closeable obj) {
		if (obj == null) {
			return;
		}
		try {
			obj.close();
		} catch (Throwable e) {

		}
	}

	public static List<String> split(String str, String sep) {
		if (str == null) {
			return null;
		}
		if (sep == null || sep.length() < 1) {
			return null;
		}
		List<String> list = new ArrayList<String>();
		int fromIndex = 0;
		int len = str.length();
		int sepLen = sep.length();
		int pos = 0;
		String tmp = null;
		// a,b,c
		while (true) {

			pos = str.indexOf(sep, fromIndex);
			if (pos < 0) {
				list.add(str.substring(fromIndex));
				break;
			}
			//System.out.println("fromIndex="+fromIndex+",pos="+pos);
			tmp = str.substring(fromIndex, pos);
			//System.out.println("tmpstr="+tmp);
			list.add(tmp);

			fromIndex = fromIndex + tmp.length() + sepLen;

		}

		return list;
	}

	public static String[] splitAsArray(String str, String sep) {
		List<String> list = split(str, sep);
		if (list == null || list.isEmpty()) {
			return null;
		}
		return (String[]) list.toArray();
	}

	public static String join(List list, String sep) {

		if (list == null || list.isEmpty()) {
			return null;
		}

		if (sep == null || sep.length() < 1) {
			sep = ",";
		}

		StringBuilder sb = new StringBuilder();
		boolean first = true;
		for (Object item : list) {

			if (first) {
				first = false;
			} else {
				sb.append(sep);
			}
			sb.append(item);
		}
		return sb.toString();
	}

	public static String doGet(String url) throws Exception {

		
		
		
		URL urlo = new URL(url);

		URLConnection conn = urlo.openConnection();
		HttpURLConnection huc = (HttpURLConnection) conn;
		
		/*
		String encode = huc.getContentEncoding();

		String contentType = huc.getContentType();

		String headContentType = huc.getHeaderField("Content-Type");

		System.out.println("encode=" + encode);
		System.out.println("contentType=" + contentType);
		System.out.println("headContentType=" + headContentType);
		*/
		String contentType = huc.getContentType();
        String charset = getCharset(contentType);
        if(isblank(charset)){
        	charset = CHARSET;
        }
		
		
		InputStream is = null;
		ByteArrayOutputStream baos= new ByteArrayOutputStream();
		int ch = 0;
		try{
		is = huc.getInputStream();
		while((ch=is.read())!=-1){
			baos.write(ch);
		}
		byte[] bytes = baos.toByteArray();
		

		return new String(bytes,charset);
		}finally{
			close(is);
		}
	}

	private static String getCharset(String str) {
		// application/x-javascript; charset=GBK
		if(isblank(str)){
			return null;
		}
		int pos = str.indexOf(CHARSET_KEY);
		if(pos >= 0){
			return str.substring(pos+CHARSET_KEY_LEN);
		}

		return null;
	}
	///
	public static String getString(Map<String,String> map,String key,String def){
		if(map==null){
			return def;
		}
		String str = map.get(key);
		if(isblank(str)){
			return def;
		}
		return str;
	}
	
	public static double getDouble(Map<String,String> map,String key,double def){
		if(map==null){
			return def;
		}
		String str = map.get(key);
		return getDouble(str,def);
	}
	
	public static int getInt(Map<String,String> map,String key,int def){
		if(map==null){
			return def;
		}
		String str = map.get(key);
		return getInt(str,def);
	}

	
	/**
	 * 
	 * @param low
	 * @param high
	 * @param now  
	 * @param lp low position
	 * @param hp high position
	 * @return
	 */
	public static double getPosition(double low,double high,double now,double lp,double hp){
		
		double v = (hp-lp) * (high - now)/(high - low);
		
		return v;
	}
	

	public static double getPosition(double low,double high,double now){
		double lp = 0;
		double hp = 0.8;
		double v = (hp-lp) * (high - now)/(high - low);
		
		return v;
	}

	
	public static String getDateString(Date date,String format){
		if(date==null){
			return null;
		}
		if (isblank(format)) {
			format = DATE_FORMAT;
		}
		
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			return sdf.format(date);
		} catch (Throwable e) {
			throw new RuntimeException("getDateString error,format=" + format + ",date=" + date, e);
		}	
	}
	
	public static String getDateString(){
		return getDateString(new Date(),null);
	}

}
