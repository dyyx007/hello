import java.util.ArrayList;
import java.util.List;



public class DailyReport {

	private static String FILE = "d:/dugang/workfun/daily-detail.txt";
	
	// hs300 index
	// stock account balance
	// money fund balance
	//  hold /  Stock market value
	//  Corrected value 
	// #buy
	// #sell
	
	
	
	
	private static final String BUY_START = "#buy";
	private static final String SELL_START = "#sell";
	
	static List<Double> values = new ArrayList<Double>();
	
	static double hs300index = 0;
	static long stockAccountBalance = 0;
	static long moneyFundBalance = 0;
	static long stockMarketValue = 0;
	static long correctedValue = 0;
	
	static long total = 0;
	
	
	static final String DATA_FORMAT_ERROR = "data fromat error";
	
	static final String SEP = "|";
	
	
	public static void main(String[] args) throws Exception {
		
		List<String> lines =  CommUtil.readLines(FILE);
		if(lines==null || lines.isEmpty()){
			System.out.println("no data");
			return;
		}
		List<TradeDTO> buys = new ArrayList<TradeDTO>();
		List<TradeDTO> sells = new ArrayList<TradeDTO>();
		boolean isbuy = false;
		boolean issell = false;
		
		
		
		TradeDTO dto = null;
		for(String line:lines){
			
			if(CommUtil.isblank(line)){
				continue;
			}
			
			
			
			
			  if(line.indexOf(BUY_START) >=0){
	        	   isbuy = true;
	        	   issell = false;
	        	   continue;
	           }
	           
	           if(line.indexOf(SELL_START) >=0){
	        	   isbuy = false;
	        	   issell = true;
	        	   continue;
	           }
			
			if(isbuy){
				
				dto = CommUtil.getTradeDTO(line);
				if(dto!=null){
					buys.add(dto);
				}
			
			}
           if(issell){
				
				dto = CommUtil.getTradeDTO(line);
				if(dto!=null){
					sells.add(dto);
				}
			}
           
           if(!isbuy && !issell){
        	   // TODO
        	   double v = CommUtil.getDouble(line,-1);
        	   if(v<0){
        		   continue;
        	   }
        	   values.add(v);
           }	
		}
		
		ResultDTO buyResult = build(buys);
		ResultDTO sellResult = build(sells);
		
	
		
		System.out.println("buy result,"+buyResult);
		System.out.println("sell result,"+sellResult);
		
		
		//System.out.println("values="+CommUtil.join(values, ","));
		if(values==null || values.size()!=5){
			System.out.println(DATA_FORMAT_ERROR);
			return;
		}
		hs300index = values.get(0);
		if(hs300index<=0){
			System.out.println(DATA_FORMAT_ERROR);
			return;
		}
		//Double tmp = values.get(1);

		stockAccountBalance =  values.get(1).longValue();
		moneyFundBalance = values.get(2).longValue();
		stockMarketValue = values.get(3).longValue();
		correctedValue =values.get(4).longValue();
		
		if(stockAccountBalance<=0){
			System.out.println(DATA_FORMAT_ERROR);
			return;
		}
		
		if(moneyFundBalance<=0){
			System.out.println(DATA_FORMAT_ERROR);
			return;
		}
		
		total = stockAccountBalance + moneyFundBalance + correctedValue;
		StringBuilder sb = new StringBuilder();
		// 20160108|886596|3361.56|505044|155425|139424
		sb.append(CommUtil.getDateString());
		sb.append(SEP).append(total);
		sb.append(SEP).append(hs300index);
		sb.append(SEP).append(stockMarketValue);
		sb.append(SEP).append(new Double(buyResult.money).longValue());
		sb.append(SEP).append(new Double(sellResult.money).longValue());
		
		System.out.println(sb);
	}
	
	private static ResultDTO build(List<TradeDTO> list){
		ResultDTO dto = new ResultDTO();
		if(list==null || list.isEmpty()){
			return dto;
		}
		int volumeSum = 0;
		double moneySum = 0;
		for(TradeDTO item:list){
			volumeSum = volumeSum +item.volume;
			moneySum = moneySum + item.volume * item.price;
		}
		dto.count = list.size();
		dto.volume = volumeSum;
		dto.money = moneySum;
		
		return dto;
	}

	
}
