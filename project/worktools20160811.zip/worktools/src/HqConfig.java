import java.util.List;


public class HqConfig {
	
	// sh510050,sh510300,sh510900,sz159901,sz159915,sh000001,sh000016,sh000300,sz399001,sz399005,sz399006
	public String codes ;
	
	public List<HqGridConfig> grids;
	
    
}
