import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class Avg {

	private static String FILE = "d:/avg.txt";
	private static String BLANK = " ";
	public static void main(String[] args) throws Exception {
		
		String str = CommUtil.readString(FILE, null);
		

		 if(CommUtil.isblank(str)){
			 System.out.println("input is blank");
			 return;
		 }
		
		
		List<Double> values = new ArrayList<Double>();
		String[]arr = str.split(BLANK);
		if(arr==null || arr.length<=0){
			System.out.println("input is blank");
			 return;
		}
	
		
		double v = 0;
		for(String item:arr){
			if(CommUtil.isblank(item)){
				continue;
			}
		    item=item.trim();
		    v = CommUtil.getDouble(item);
		    if(v<=0){
		    	continue;
		    }
		    values.add(v);
		}
		int count = values.size();
		if(count<=0){
			System.out.println("input is blank");
			 return;
		}
		Collections.sort(values);
		
		
		StringBuilder sb = new StringBuilder();
		sb.append("values=");
		double sum = 0;
		for(Double item:values){
			sum = sum+item.doubleValue();
			sb.append(item+",");
		}
		double avg = sum/count;
		sb.append("\n sum="+sum+",avg="+CommUtil.format(avg, "0.#####")+",count="+count);
		
		System.out.println(sb);
		
	}

	
}
