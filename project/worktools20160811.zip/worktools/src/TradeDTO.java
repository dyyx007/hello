
public class TradeDTO {


	public double price;
	public int volume;
	

	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("price=" + price);
		sb.append(",volume=" + volume);
		
		return sb.toString();
	}
}
