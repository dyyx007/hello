import java.util.HashMap;
import java.util.Map;


public class Grid {

	private static Map<String, String> params = null;
	
	private static final String F = "0.000";
	
	public static void main(String[] args) throws Exception {
		
		params = CommUtil.getArgMap(args);
		if (params == null) {
			params = new HashMap<String, String>();
		}
		//
		params.put("low","2.974");
		params.put("high","3.672");
		params.put("count","12");
		
		//
		double high = CommUtil.getDouble(params, "high", 0);
		double low = CommUtil.getDouble(params, "low", 0);
		// high position
		double hp = CommUtil.getDouble(params, "hp", 0.80);
		double lp = CommUtil.getDouble(params, "lp", 0);
		
		if(high<=0 || low<=0 || high<=low){
			System.out.println("high low error");
			return;
		}
		

		if(hp<=0 || lp<0 || hp<=lp){
			System.out.println("high low position error");
			return;
		}
		
		
		
		
		double now =  CommUtil.getDouble(params, "now", 0);
		
		int count =  CommUtil.getInt(params, "count", 10);
		
		if(count <=1 ){
			System.out.println("count error");
			return;
		}
		///
		double gap = (high-low) / count;
		double v = 0;
		double position = 0;
		for(int i=0;i<=count;i++){
			
			v = high - gap * i;
			position = getPosition( low, high, v, lp, hp) ;
			System.out.println( CommUtil.format(v, F)+","+   CommUtil.format(position*100, F));
			
		}
		
		
		
		
		
	}
	
	private static double getPosition(double low,double high,double now,double lp,double hp){
		
		double v = (hp-lp) * (high - now)/(high - low);
		
		return v;
	}

	

}
