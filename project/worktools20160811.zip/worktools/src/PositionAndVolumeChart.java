import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.DateTickUnit;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.time.Day;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;

public class PositionAndVolumeChart {

	
    //position and volume
	private static String title = "position";

	private static String DEST_FILE = DyyxConst.DEST_DIR+"pv.jpg";

	private static int xLableNum = 20;
	private static int tickCount = 5;

	private static int totalDataNum = 0;
	private static int chartDataNum = 0;
	private static String start = null;
	
	private static final double BASE = 10000.0;

	private static Map<String, String> map = null;

	public static void main(String[] args) throws Exception {

		map = CommUtil.getArgMap(args);
		if (map == null) {
			map = new HashMap<String, String>();
		}
		//a=1#b=2
		String xLableNumStr = map.get("xnum");
		int xLableNumTmp = CommUtil.getInt(xLableNumStr);
		if (xLableNumTmp > 2) {
			xLableNum = xLableNumTmp;
		}
	    start = map.get("start");

		List<DataDTO> list = CommUtil.readData(CommUtil.DATA_FILE);
		CommUtil.buildDataDTO(list);
		//System.out.println("list.size="+list.size());
		totalDataNum = list.size();

		list = getDataList(list, start);

		chartDataNum = list.size();

		System.out.println("chartDataNum=" + chartDataNum);

		TimeSeries pts = new TimeSeries("position");
		TimeSeries vts = new TimeSeries("volume");
		TimeSeries bvts = new TimeSeries("buy-volume");
		TimeSeries svts = new TimeSeries("sell-volume");
		
		
		
		for (DataDTO item : list) {
			
			
			//pts.add(new Day(item.timeDate), getValue(item.position));
			pts.add(new Day(item.timeDate), getPosition(item));
			//vts.add(new Day(item.timeDate), getValue(item.bv+item.sv));
			//bvts.add(new Day(item.timeDate), getValue(item.bv));
			//svts.add(new Day(item.timeDate), getValue(item.sv));
		}

		build(list);
		
		info();

		TimeSeriesCollection dataset = new TimeSeriesCollection();
		dataset.addSeries(pts);
		//dataset.addSeries(vts);
		//dataset.addSeries(bvts);
		//dataset.addSeries(svts);
        String ytitle = title;
		JFreeChart chart = ChartFactory.createTimeSeriesChart(title, "time", ytitle, dataset, true, true, false);

		XYPlot xyplot = (XYPlot) chart.getPlot();
		DateAxis domainAxis = (DateAxis) xyplot.getDomainAxis();

		System.out.println("tickCount=" + tickCount);

		domainAxis.setTickUnit(new DateTickUnit(DateTickUnit.DAY, tickCount, new SimpleDateFormat("yyyy-MM-dd")));
		domainAxis.setVerticalTickLabels(true);
		//domainAxis.setLabelAngle(45);
		//domainAxis.setDateLabelPositions(CategoryLabelPositions.DOWN_45);

		XYLineAndShapeRenderer xylinerenderer=(XYLineAndShapeRenderer)xyplot.getRenderer();
		
		//xylinerenderer.setSeriesPaint(0, new Color(255, 0 ,0 ));
		//xylinerenderer.setSeriesPaint(1, new Color(0, 255 ,0 ));
		//xylinerenderer.setSeriesPaint(2, new Color(0, 0 ,255 ));
		//xylinerenderer.setSeriesPaint(3, new Color(255,0 ,255 ));
		

		// Output
		File outputFile = new File(DEST_FILE);
		ChartUtilities.saveChartAsPNG(outputFile, chart, CommUtil.width, CommUtil.height_pv);

		System.out.println("position and volume chart done");

	}

	private static int getPosition(DataDTO item){
		int position = item.position;
		double nv = item.nv;
		if(position <0 || nv <= 0){
			return 0;
		}
		double v = BASE * position / nv;
		
		return new Double(v).intValue();
	}
	
	
	private static int getValue(double v){
		if(v<=CommUtil.min || v<=CommUtil.min){
			return 0;
		}
		double  tmp = v /1000.0;
		if(tmp<=CommUtil.min ){
			return 0;
		}
		tmp = CommUtil.format(tmp, "0.00");
		Double tmpo = new Double(tmp);
		return tmpo.intValue();
		     
	}
	
	private static int getStartIndex(List<DataDTO> list, String start) {
		if (list == null || list.isEmpty()) {
			return 0;
		}
		if (CommUtil.isblank(start)) {
			return 0;
		}

		String time = null;
		int num = list.size();
		DataDTO dto = null;
		for (int i = 0; i < num; i++) {
			dto = list.get(i);
			time = dto.time;
			if (start.equals(time)) {
				return i;
			}

		}

		return 0;
	}

	private static List<DataDTO> getDataList(List<DataDTO> list, String start) {
		List<DataDTO> resultList = new ArrayList<DataDTO>();
		if (list == null || list.isEmpty()) {
			return resultList;
		}

		int startIndex = getStartIndex(list, start);
		if (startIndex <= 0) {
			return list;
		}
		int num = list.size();
		for (int i = startIndex; i < num; i++) {
			resultList.add(list.get(i));
		}

		return resultList;
	}

	private static void build(List<DataDTO> list) {
		if (list == null || list.isEmpty()) {
			return;
		}
		int num = list.size();
		if (num <= 1) {
			return;
		}
		double nvindex = 0;
		double hs300index = 0;
		double minTmp = 0;
		double maxTmp = 0;
		for (DataDTO item : list) {
			nvindex = item.nvindex;
			hs300index = item.hs300index;

			if (nvindex < hs300index) {
				minTmp = nvindex;
				maxTmp = hs300index;
			} else {
				minTmp = hs300index;
				maxTmp = nvindex;
			}

	
		}
		//


		//

		if (num > xLableNum) {
			tickCount = num / xLableNum;
		}
		if (tickCount <= 0) {
			tickCount = 1;
		}

	
	

	}

	private static void info(){
		StringBuilder info = new StringBuilder();
		//info.append("low="+low+",up="+up+",min="+min+",max="+max);
		info.append(",xLableNum="+xLableNum+",tickCount="+tickCount);
		
		info.append(",totalDataNum="+totalDataNum+",chartDataNum="+chartDataNum+",start="+start);
		info.append(",argMap="+map);
		System.out.println(info);
	}

}
