import java.util.Date;
import java.util.HashMap;
import java.util.Map;


public class MaAndBiasDataDTO  implements Comparable<MaAndBiasDataDTO>  {
	
	public String timestr;
	public Date time;
	// price or index
	public double value;
	// key  ma_5 ma_10 ...  bias_5 bias_10 ...
	
    private Map<String,Double> dataMap = new HashMap<String,Double>();
    
	private static final String  SEP = "_";
	public static final int  MIN_PERIOD = 5;
	private static final double  MIN_VALUE = 0.000001;
	
	private static final String  MA = "ma";
	private static final String  BIAS = "bias";

	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("timestr=" + timestr);
		sb.append(",time=" + time);
		sb.append(",value=" + value);
		sb.append(",dataMap=" + dataMap);
		return sb.toString();
	}
	
	public void addMaData(int period,double value ){
		if(period<MIN_PERIOD){
			return ;
		}
		if(value < MIN_VALUE){
			return ;
		}
		String key = MA+SEP+period;
		dataMap.put(key, value);
	}
	
	public void addBiasData(int period,double value ){
		if(period<MIN_PERIOD){
			return ;
		}
		//if(value < MIN_VALUE){
		//	return ;
		//}
		//if(value==0){
		//	return ;
		//}
		String key = BIAS+SEP+period;
		dataMap.put(key, value);
	}
	
	public Double getMaData(int period){
		if(period<MIN_PERIOD){
			return null;
		}
		String key = MA+SEP+period;
		return dataMap.get(key);
	}
	
	public Double getBiasData(int period){
		if(period<MIN_PERIOD){
			return null;
		}
		String key = BIAS+SEP+period;
		return dataMap.get(key);
	}
	
	public int compareTo(MaAndBiasDataDTO other) {
		if(other==null){
			return 1;
		}
		
		Date timeother = other.time;
		
		if(time==null && timeother==null){
			return 0;
		}
		if(time==null && timeother!=null){
			return -1;
		}
		if(time!=null && timeother==null){
			return 1;
		}
		
		return time.compareTo(timeother);
		
	}
	
}
