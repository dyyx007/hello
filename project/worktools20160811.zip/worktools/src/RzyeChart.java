import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

public class RzyeChart {

	private static final String DATA_FILE = "d:/dugang/workfun/rzye.txt";
	
	

	private static final String EMPTY = "";

	private static final double DIF = 50;

	private static double min = 0;
	private static double max = 0;
	private static double low = 0;
	private static double up = 0;

	private static int winCount = 0;
	private static int lostCount = 0;

	private static int winVsIndexCount = 0;
	private static int lostVsIndexCount = 0;

	private static double winRate = 0;
	private static double aqi = 0;
	private static String info = null;
	private static String title = " rzye";

	private static double nv0 = 0;
	private static double nv = 0;

	public static void main(String[] args) throws Exception {
		System.out.println("hello rzye chart");

		//ChartUtilities.saveChartAsPNG
		//ChartUtilities.saveChartAsPNG(new File("d:/xxx.jpg"), chart, 550, 250); 

		Map<String, String> argMap = getArgMap(args);
		System.out.println("argMap=" + argMap);

		String start = null;
		String showshape = null;

		if (argMap != null) {
			start = argMap.get("start");
			showshape = argMap.get("showshape");
		}
		boolean showShape = false;
		if ("1".equals(showshape)) {
			showShape = true;
		}
		System.out.println("showShape=" + showShape);
		List<DataDTO> list = readData();

		list = getDataList(list, start);

		std(list);

		if (list != null) {
			System.out.println("data num " + list.size());
			for (DataDTO item : list) {
				System.out.println(item);
			}
		}

	

		JFreeChart chart = createChart(createDataset(list), showShape);
		String file = "d:/rzye.jpg";
		int width = 800;
		int height = 600;
		ChartUtilities.saveChartAsJPEG(new File(file), chart, width, height);

		System.out.println("my fund chart  done!" + System.currentTimeMillis());
		System.out.println(title);
		//

	}

	
	private static List<DataDTO> getDataList(List<DataDTO> list, String start) {
		if (list == null || list.isEmpty() || isblank(start)) {
			return list;
		}
		int startindex = 0;
		int num = list.size();
		for (int i = 0; i < num; i++) {
			if (start.equals(list.get(i).time)) {
				startindex = i;
				break;
			}
		}

		System.out.println("startindex=" + startindex + ",start=" + start);

		List<DataDTO> listnew = new ArrayList<DataDTO>();
		for (int i = startindex; i < num; i++) {
			listnew.add(list.get(i));
		}

		return listnew;
	}

	private static Map<String, String> getArgMap(String[] args) {
		if (args == null) {
			System.out.println("args is null");
			return null;
		}
		int num = args.length;
		System.out.println("args num " + num);
		String str =null;
		if(num>0){ str = args[0];}
		return getArgMap(str);
	}

	private static Map<String, String> getArgMap(String str) {
		// a=1#b=2
		Map<String, String> m = new HashMap<String, String>();
		if (isblank(str)) {
			return m;
		}
		String[] arr = str.split("#");
		if (arr == null || arr.length <= 0) {
			return m;
		}
		String[] arr2 = null;
		String key, value;
		for (String item : arr) {
			arr2 = item.split("=");
			if (arr2 == null || arr2.length != 2) {
				continue;
			}
			key = arr2[0];
			value = arr2[1];
			if (isblank(key) || isblank(value)) {
				continue;
			}
			key = key.trim();
			value = value.trim();
			m.put(key, value);
		}
		return m;
	}

	private static CategoryDataset createDataset(List<DataDTO> list) throws Exception {

		DefaultCategoryDataset dataset = new DefaultCategoryDataset();

		if (list == null || list.isEmpty()) {
			return dataset;
		}

		String rzyeType = "rzye";


        String time = null;

		for (DataDTO item : list) {
			if (item == null) {
				continue;
			}
			time = item.time;
			
			addValue(dataset, item.rzye,rzyeType, time);
		
		}

		if (max > 0) {
			up = max + DIF;
			low = min - DIF;
			if (low < 0) {
				low = 0;
			}
		}

		System.out.println("min=" + min + ",max=" + max);
		System.out.println("low=" + low + ",up=" + up);

		return dataset;

	}

	private static void addValue(DefaultCategoryDataset ds, double value, Comparable rowKey, Comparable columnKey) {
		if (value <= 0) {
			return;
		}
		ds.addValue(value, rowKey, columnKey);

		if (min <= 0) {
			min = value;
			max = value;
			return;
		}
		if (value < min) {
			min = value;
		}
		if (value > max) {
			max = value;
		}

	}

	private static void std(List<DataDTO> list) throws Exception {
		if (list == null || list.isEmpty()) {
			return;
		}
		
	}

	private static JFreeChart createChart(CategoryDataset dataset, boolean showshape) {

		// create the chart...
		JFreeChart chart = ChartFactory.createLineChart(title, // chart title
				"time", // domain axis label
				"index", // range axis label
				dataset, // data
				PlotOrientation.VERTICAL, // orientation
				true, // include legend
				true, // tooltips
				false // urls
				);

		chart.setBackgroundPaint(Color.white);

		CategoryPlot plot = (CategoryPlot) chart.getPlot();
		plot.setBackgroundPaint(Color.lightGray);
		plot.setRangeGridlinePaint(Color.white);

		CategoryItemRenderer render = plot.getRenderer();
		boolean showValues = false;

		if (render != null && showValues) {
			// show values
			render.setBaseItemLabelsVisible(true);
			render.setBaseItemLabelGenerator(new StandardCategoryItemLabelGenerator());
		}

		// customise the range axis...
		NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
		//rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());

		//rangeAxis.setAutoRange(true);

		//rangeAxis.setAutoRangeMinimumSize(3500);
		if (up > 0) {
			rangeAxis.setRange(low, up);
		}

		//rangeAxis.setLowerBound(3500);

		CategoryAxis caxis = plot.getDomainAxis();
		caxis.setCategoryLabelPositions(CategoryLabelPositions.DOWN_45);

		// customise the renderer...
		LineAndShapeRenderer renderer = (LineAndShapeRenderer) plot.getRenderer();
		if (showshape) {
			renderer.setSeriesShapesVisible(0, true);
			renderer.setSeriesShapesVisible(1, true);
		}

		//renderer.setSeriesShapesVisible(2, true);
		//renderer.setSeriesLinesVisible(2, false);
		//renderer.setSeriesShape(2, ShapeUtilities.createDiamond(4.0f));
		//renderer.setDrawOutlines(true);
		//renderer.setUseFillPaint(true);
		//renderer.setFillPaint(Color.white);

		return chart;

	}

	private static List<DataDTO> readData() throws Exception {
		List<DataDTO> list = new ArrayList<DataDTO>();

		List<String> lines = readLines(DATA_FILE);
		if (lines == null || lines.isEmpty()) {
			return list;
		}

		
		DataDTO dto;
		for (String line : lines) {
			if (line == null) {
				continue;
			}
			line = line.trim();
			if (line.length() <= 0) {
				continue;
			}
			line = line.replaceAll("\t", " ");
			line = line.replaceAll(",", "");
			
	        System.out.println(line);
	        
	        List<String> itemlist = new ArrayList<String>();
	        
	        String[]arr = line.split(" ");
	        for(String item:arr){
	        	if(isblank(item)){
	        		continue;
	        	}
	        	item = item.trim();
	        	itemlist.add(item);
	        }
	        if(itemlist.size() <2){
	        	continue;
	        }

			dto = new DataDTO();
            String time = itemlist.get(0);
            double rzye = getDouble(itemlist.get(1)) ;
            if(rzye<=0){
            	continue;
            }
            dto.time = time;
            dto.rzye = rzye;

			list.add(dto);
		}

		return list;
	}

	private static List<String> readLines(String file) throws Exception {
		List<String> list = new ArrayList<String>();
		BufferedReader br = null;

		//InputStream is = new FileInputStreamReader(file);
		//InputStream is = new FileInputStream(new File(file));  

		br = new BufferedReader(new FileReader(file));
		String line = null;
		while ((line = br.readLine()) != null) {
			if (isblank(line)) {
				continue;
			}
			line = line.trim();
			list.add(line);
		}
		br.close();
		return list;
	}

	private static boolean isblank(String str) {
		if (str == null || EMPTY.equals(str)) {
			return true;
		}
		String tmp = str.trim();
		if (tmp.length() <= 0) {
			return true;
		}
		return false;
	}

	private static double getDouble(String str) {
		try {
			return Double.parseDouble(str);
		} catch (Throwable e) {
			return 0;
		}
	}

	private static double format(double v) {
		DecimalFormat df = new DecimalFormat("0.##");
		String str = df.format(v);
		return getDouble(str);
	}

}
