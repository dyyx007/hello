
public class HqData {
    public String code;
	public String time;
	public String name;
	/**
	 * ��������
	 */
	public double yclose;
	/**
	 * ����
	 */
	public double open;
	public double now;
	public double min;
	public double max;
	/**
	 * 
	 */
	public double delta;
	/**
	 *  �Ƿ� ����� ��������
	 */
	public double deltap;
	
	/**
	 * �Ƿ� ����ڿ��� 
	 */
	//public double dif;
	
	//public double difp;
	
	/**
	 *   ���
	 */
	public double v;
	public double vp;
	
	/**
	 *  B(buy) or S (sell)
	 *  �������� ��������
	 */
	public String flag;
	
	/**
	 * �������λ
	 */
	public double position;
	
	/**
	 * �����ߵ��µ�����
	 */
	public double fall;
	
	public static final double R = 0.25;
	public static final double R_MAX = 0.45;
	
	public double r = R;
	
	
	
	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("code=" + code);
		sb.append(",name=" + name);
		sb.append(",time=" + time);
		
		sb.append(",yclose=" + yclose);
		sb.append(",open=" + open);
		sb.append(",now=" + now);
		sb.append(",min=" + min);
		sb.append(",max=" + max);
		
		sb.append(",delta=" + delta);
		sb.append(",deltap=" + deltap);
		
		//sb.append(",dif=" + dif);
		//sb.append(",dif=" + difp);
		
		sb.append(",v=" + v);
		sb.append(",vp=" + vp);
		sb.append(",flag=" + flag);
		sb.append(",r=" + r);
		
		sb.append(",position=" + position);
		sb.append(",fall=" + fall);
		
		return sb.toString();
	}
	
	public void buildFlag(){
		if(vp < 1.0){
			return;
		}
		if(r>=R_MAX){
			return ;
		}
		double buyv = min + v*r;
		double sellv = max - v*r;
		
		if(now < buyv){
			flag = "B";
		}
		
		if(now>sellv){
			flag = "S";
		}
		
	}
	
}
