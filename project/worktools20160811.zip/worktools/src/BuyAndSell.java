import java.util.ArrayList;
import java.util.List;



public class BuyAndSell {

	private static String FILE = "d:/trade.txt";
	
	private static final String BUY_START = "#buy";
	private static final String SELL_START = "#sell";
	
	
	public static void main(String[] args) throws Exception {
		
		List<String> lines =  CommUtil.readLines(FILE);
		if(lines==null || lines.isEmpty()){
			System.out.println("no data");
			return;
		}
		List<TradeDTO> buys = new ArrayList<TradeDTO>();
		List<TradeDTO> sells = new ArrayList<TradeDTO>();
		boolean isbuy = false;
		boolean issell = false;
		
		
		
		TradeDTO dto = null;
		for(String line:lines){
			
			if(CommUtil.isblank(line)){
				continue;
			}
			
			  if(line.indexOf(BUY_START) >=0){
	        	   isbuy = true;
	        	   issell = false;
	        	   continue;
	           }
	           
	           if(line.indexOf(SELL_START) >=0){
	        	   isbuy = false;
	        	   issell = true;
	        	   continue;
	           }
			
			if(isbuy){
				
				dto = CommUtil.getTradeDTO(line);
				if(dto!=null){
					buys.add(dto);
				}
			
			}
           if(issell){
				
				dto = CommUtil.getTradeDTO(line);
				if(dto!=null){
					sells.add(dto);
				}
			
				
			}
			
		}
		
		ResultDTO buyResult = build(buys);
		ResultDTO sellResult = build(sells);
		
		System.out.println("buy result,"+buyResult);
		System.out.println("sell result,"+sellResult);
	}
	
	private static ResultDTO build(List<TradeDTO> list){
		ResultDTO dto = new ResultDTO();
		if(list==null || list.isEmpty()){
			return dto;
		}
		int volumeSum = 0;
		double moneySum = 0;
		for(TradeDTO item:list){
			volumeSum = volumeSum +item.volume;
			moneySum = moneySum + item.volume * item.price;
		}
		dto.count = list.size();
		dto.volume = volumeSum;
		dto.money = moneySum;
		
		return dto;
	}

	
}
