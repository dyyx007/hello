import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.DateTickUnit;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.time.Day;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;

public class MyFundChart2 {

	

	private static final double DIF = 50;

	private static double min = 0;
	private static double max = 0;
	private static double low = 0;
	private static double up = 0;

	private static double aqi = 0;
	private static double nv0 = 0;
	private static double nv = 0;
	//private static String info = null;
	private static String title = "AQI VS HS300 ";

	private static String DEST_FILE = DyyxConst.DEST_DIR+"aqi2.jpg";

	private static int xLableNum = 20;
	private static int tickCount = 5;

	private static int totalDataNum = 0;
	private static int chartDataNum = 0;
	private static String start = null;

	private static Map<String, String> map = null;
	
	private static DataDTO lastYearData;
	private static DataDTO lastMonthData;
	private static DataDTO lastWeekData;
	private static DataDTO nowData;
	private static DataDTO firstData;
	// year yield
	private static double yy = 0;
	

	public static void main(String[] args) throws Exception {

		map = CommUtil.getArgMap(args);
		if (map == null) {
			map = new HashMap<String, String>();
		}
		//a=1#b=2
		String xLableNumStr = map.get("xnum");
		int xLableNumTmp = CommUtil.getInt(xLableNumStr);
		if (xLableNumTmp > 2) {
			xLableNum = xLableNumTmp;
		}
	    start = map.get("start");

		List<DataDTO> list = CommUtil.readData(CommUtil.DATA_FILE);
		CommUtil.buildDataDTO(list);
		//System.out.println("list.size="+list.size());
		totalDataNum = list.size();

		list = getDataList(list, start);

		chartDataNum = list.size();

		System.out.println("chartDataNum=" + chartDataNum);

		TimeSeries aqits = new TimeSeries("aqi");
		TimeSeries hs300ts = new TimeSeries("hs300");

		for (DataDTO item : list) {
			aqits.add(new Day(item.timeDate), item.nvindex);
			hs300ts.add(new Day(item.timeDate), item.hs300index);
		}

		build(list);
		
		// TODO  build last data
		
		buildLastData(list);
		buildYield();
		info();

		TimeSeriesCollection dataset = new TimeSeriesCollection();
		dataset.addSeries(aqits);
		dataset.addSeries(hs300ts);

		

		JFreeChart chart = ChartFactory.createTimeSeriesChart(title, "time", "index", dataset, true, true, false);

		XYPlot xyplot = (XYPlot) chart.getPlot();
		DateAxis domainAxis = (DateAxis) xyplot.getDomainAxis();

		System.out.println("tickCount=" + tickCount);

		domainAxis.setTickUnit(new DateTickUnit(DateTickUnit.DAY, tickCount, new SimpleDateFormat("yyyy-MM-dd")));
		domainAxis.setVerticalTickLabels(true);
		//domainAxis.setLabelAngle(45);
		//domainAxis.setDateLabelPositions(CategoryLabelPositions.DOWN_45);

		// customise the range axis...
		NumberAxis rangeAxis = (NumberAxis) xyplot.getRangeAxis();
		//rangeAxis.setVerticalTickLabels(true);
		//rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());

		//rangeAxis.setAutoRange(true);

		//rangeAxis.setAutoRangeMinimumSize(3500);
		if (up > 0 && low >= 0) {
			rangeAxis.setRange(low, up);
		}

		// Output
		File outputFile = new File(DEST_FILE);
		ChartUtilities.saveChartAsPNG(outputFile, chart, CommUtil.width, CommUtil.height);

		System.out.println("chart2 done,"+title);

	}

	private static void buildLastData(List<DataDTO> list){
		if(list==null || list.isEmpty()){
			return;
		}
		int num = list.size();
		if(num<=1){
			return;
		}
		nowData = list.get(num-1);
		firstData = list.get(0);
		
		int nowYear = nowData.timeDate.getYear();
		int nowMonth = nowData.timeDate.getMonth();
		int weekDay = nowData.timeDate.getDay();

		DataDTO item = null;
		for(int i=num-1;i>=0;i--){
			item = list.get(i);
			
			if((lastYearData==null) && (item.timeDate.getYear()!=nowYear)){
				lastYearData = item;
			}
		}
		
	}
	
	
	private static void buildYield(){
		 if(totalDataNum<=1){
			 return;
		 }
		 if(lastYearData==null){
			 return;
		 }
		 double nv = nowData.nv;
		 double nv0 = lastYearData.nv;
		 // year yield
		 yy = (nv-nv0) * 100 / nv0;
		 title = title+",yy=" + CommUtil.format(yy) + "%";
	}
	
	private static int getStartIndex(List<DataDTO> list, String start) {
		if (list == null || list.isEmpty()) {
			return 0;
		}
		if (CommUtil.isblank(start)) {
			return 0;
		}

		String time = null;
		int num = list.size();
		DataDTO dto = null;
		for (int i = 0; i < num; i++) {
			dto = list.get(i);
			time = dto.time;
			if (start.equals(time)) {
				return i;
			}

		}

		return 0;
	}

	private static List<DataDTO> getDataList(List<DataDTO> list, String start) {
		List<DataDTO> resultList = new ArrayList<DataDTO>();
		if (list == null || list.isEmpty()) {
			return resultList;
		}

		int startIndex = getStartIndex(list, start);
		if (startIndex <= 0) {
			return list;
		}
		int num = list.size();
		for (int i = startIndex; i < num; i++) {
			resultList.add(list.get(i));
		}

		return resultList;
	}

	private static void build(List<DataDTO> list) {
		if (list == null || list.isEmpty()) {
			return;
		}
		int num = list.size();
		if (num <= 1) {
			return;
		}
		double nvindex = 0;
		double hs300index = 0;
		double minTmp = 0;
		double maxTmp = 0;
		for (DataDTO item : list) {
			nvindex = item.nvindex;
			hs300index = item.hs300index;

			if (nvindex < hs300index) {
				minTmp = nvindex;
				maxTmp = hs300index;
			} else {
				minTmp = hs300index;
				maxTmp = nvindex;
			}

			if (min <= 0 && minTmp > 0) {
				min = minTmp;
			}

			if (min > 0 && minTmp > 0 && minTmp < min) {
				min = minTmp;
			}
			//
			if (max <= 0 && maxTmp > 0) {
				max = maxTmp;
			}

			if (max > 0 && maxTmp > 0 && maxTmp > max) {
				max = maxTmp;
			}
			//
		}
		//

		if (max > 0) {
			up = max + DIF;

		}
		if (min > 0) {

			low = min - DIF;
			if (low < 0) {
				low = 0;
			}
		}
		//

		if (num > xLableNum) {
			tickCount = num / xLableNum;
		}
		if (tickCount <= 0) {
			tickCount = 1;
		}

		//
		DataDTO first = list.get(0);
		DataDTO last = list.get(num - 1);
		aqi = last.nvindex;
		hs300index = last.hs300index;

		nv0 = first.nv;
		nv = last.nv;

		double profit = (nv - nv0) * 100.0 / nv0;
		
		//System.out.println("nv="+nv+",nv0="+nv0);
		
		double position = last.position * 100.0 / nv ;

		//title = title + ",aqi=" + aqi + ",y=" + CommUtil.format(profit) + "%"+",p="+CommUtil.format(position)+"%";
		
		title = "hs300="+ last.hs300index + ",aqi=" + aqi +",p="+CommUtil.format(position)+"%"+ ",y=" + CommUtil.format(profit) + "%";
		
        // wy my yy week yield  month yield year yield
		//
		
		
	}

	private static void info(){
		StringBuilder info = new StringBuilder();
		info.append("low="+low+",up="+up+",min="+min+",max="+max);
		info.append(",xLableNum="+xLableNum+",tickCount="+tickCount);
		
		info.append(",totalDataNum="+totalDataNum+",chartDataNum="+chartDataNum+",start="+start);
		info.append(",argMap="+map);
		System.out.println(info);
	}

}
