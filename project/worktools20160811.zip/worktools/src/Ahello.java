



public class Ahello {
	private static final String STR_0 = "0";
	private static final String SEP2 = "/";
	public static void main(String[] args) throws Exception {
		
		System.out.println(" hello work fun 2");
		String str = "0086";
		System.out.println(str+","+format(str));
		
		str = "86";
		System.out.println(str+","+format(str));
		
		str = "806";
		System.out.println(str+","+format(str));
		
		str = "6";
		System.out.println(str+","+format(str));
		
		str = "0";
		System.out.println(str+","+format(str));
		System.out.println("/////");
		str="";
		System.out.println(str+","+getChineseString(str));
		str="a/b";
		
		System.out.println(str+","+getChineseString(str));
		str="ab/";
		System.out.println(str+","+getChineseString(str));
		str="ab";
		System.out.println(str+","+getChineseString(str));
	}
	
	private static String getChineseString(String str){
		if(CommUtil.isblank(str)){
			return str;
		}
		int pos = str.indexOf(SEP2);
		if(pos<0){
			return str;
		}
		return str.substring(pos+1);
	}

	
	private static String format(String mobileInternationalCode){
		if(CommUtil.isblank(mobileInternationalCode)){
			return mobileInternationalCode;
		}
		mobileInternationalCode = mobileInternationalCode.trim();
		while(true){
			if(mobileInternationalCode.length()<=1){
				break;
			}
			if(mobileInternationalCode.startsWith(STR_0)){				
				mobileInternationalCode = mobileInternationalCode.substring(1);
			}else{
				break;
			}
		}
		return mobileInternationalCode;
	}
	
}
