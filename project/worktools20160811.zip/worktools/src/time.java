import java.util.Date;


public class time {
	
	private static long ONE_SECOND = 1000L;
	private static long ONE_MINUTE = ONE_SECOND * 60L;
	private static long ONE_HOUR = ONE_MINUTE * 60L;
	private static long ONE_DAY= ONE_HOUR * 24L;
	
	
	
	public static void main(String[] args) throws Exception {

		Date now = new Date();
		
		System.out.println("date="+now.getDate());
		System.out.println("day="+now.getDay());
		
		System.out.println("year="+now.getYear());
		System.out.println("month="+now.getMonth());
		//System.out.println("week="+now.get);
		dateInfo(now);
		Date d1 = new Date(now.getTime()+ONE_DAY);
		dateInfo(d1);
		
		Date d2 = new Date(now.getTime() + ONE_DAY*40);
		dateInfo(d2);
		
		Date d3 = new Date(now.getTime() + ONE_DAY*365);
		dateInfo(d3);
		
		Date d4 = new Date(now.getTime() + ONE_DAY*70);
		dateInfo(d4);
		Date d5 = new Date(now.getTime() + ONE_DAY*100);
		dateInfo(d5);
		
	}
	
	private static void dateInfo(Date date){
		String s = date+"";
		s=s+",date="+date.getDate();
		s=s+",day="+date.getDay();
		s=s+",year="+date.getYear();
		s=s+",month="+date.getMonth();
		System.out.println(s);
	}

	
}
