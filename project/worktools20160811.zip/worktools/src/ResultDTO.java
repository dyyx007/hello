
public class ResultDTO {

	public int count;
	public int volume;
	public double money;
	
	
	

	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("count=" + count);
		sb.append(",volume=" + volume);
		sb.append(",money=" + money);

		return sb.toString();
	}
}
