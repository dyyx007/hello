package util;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class HtaoCommUtil {
	
	public static String WORK_DIR = "d:/eclipsework2/worktools/data/";
	
	
	
	public static int width = 800;
	public static int height = 600;
	public static int height_pv = 500;
	
	public static double min = 0.0000001;

	private static final String EMPTY = "";
	
	public static String BLANK = " ";
	
	private static final String DATE_FORMAT = "yyyyMMdd";
	
	public static final String DATA_FILE = "d:/dugang/workfun/daily-data.txt";
	public static final String DEST_FILE = "d:/aqi.jpg";
	//private static final double DIF = 50;
	public static final String CHARSET = "utf-8";
	
	public static final String SEP = "\\|";
	
	
	
	public static void main(String[] args) throws Exception {
		
		System.out.println("comm util");
		//System.currentTimeMillis();
	}

	public static boolean isblank(String str) {
		if (str == null || EMPTY.equals(str)) {
			return true;
		}
		String tmp = str.trim();
		if (tmp.length() <= 0) {
			return true;
		}
		return false;
	}

	public static double getDouble(String str) {
		return getDouble(str,0);
	}
	
	public static double getDouble(String str,double def) {
		if(isblank(str)){
			return def;
		}
		str = str.trim();
		try {
			return Double.parseDouble(str);
		} catch (Throwable e) {
			return def;
		}
	}
	
	public static int getInt(String str) {
		return getInt(str,0);
	}
	
	public static int getInt(String str,int def) {
		if(isblank(str)){
			return def;
		}
		str = str.trim();
		try {
			return Integer.parseInt(str);
		} catch (Throwable e) {
			return def;
		}
	}


	public static double format(double v,String format) {
		DecimalFormat df = new DecimalFormat(format);
		String str = df.format(v);
		return getDouble(str);
	}
	
	
	public static double format(double v) {
		DecimalFormat df = new DecimalFormat("0.##");
		String str = df.format(v);
		return getDouble(str);
	}
	
	public static Map<String, String> getArgMap(String[] args) {
		
		Map<String, String> map = new HashMap<String, String>();
		
		if (args == null) {
			System.out.println("args is null");
			return map;
		}
		int num = args.length;
		System.out.println("args num " + num);
		String str = null;
		if(num>0){
		 str = args[0];
		}
		return getArgMap(str);
	}

	public static Map<String, String> getArgMap(String str) {
		// a=1#b=2
		Map<String, String> m = new HashMap<String, String>();
		if (isblank(str)) {
			return m;
		}
		String[] arr = str.split("#");
		//String[] arr = split(str,"#");
		if (arr == null || arr.length <= 0) {
			return m;
		}
		String[] arr2 = null;
		String key, value;
		for (String item : arr) {
			arr2 = item.split("=");
			if (arr2 == null || arr2.length != 2) {
				continue;
			}
			key = arr2[0];
			value = arr2[1];
			if (isblank(key) || isblank(value)) {
				continue;
			}
			key = key.trim();
			value = value.trim();
			m.put(key, value);
		}
		return m;
	}
	
	
	
	
	public static Date getDate(String str,String format){
		 if(isblank(str)){
			 return null;
		 }
		 if(isblank(format)){
			 format = DATE_FORMAT;
		 }
		 try{
		 SimpleDateFormat sdf = new SimpleDateFormat(format);
		 return sdf.parse(str);
		 }catch(Throwable e){
			 throw new RuntimeException("getDate error,format="+format+",str="+str,e);
		 }	
	}
	
	public static Date getDate(String str,String format,Date def){
		 try{
			 return getDate(str,format);
		 }catch(Throwable e){
			 return def;
		 }
	}
	
	public static Date getDate(String str){
		 return getDate(str,null,null);
	}
	
	
	
	
	
	/////  

	public static List<String> readLines(String file) throws Exception {		
	      return readLines(file,CHARSET);	
	}

	public static List<String> readLines(String file,String charset) throws Exception {
		if(isblank(charset)){
			charset = CHARSET;
		}
		List<String> list = new ArrayList<String>();
		BufferedReader br = null;

		//InputStream is = new FileInputStreamReader(file);
		//InputStream is = new FileInputStream(new File(file));  
		FileInputStream	 fis = null;
		
		try{
			
	  	fis = new FileInputStream(file);
	  	Reader reader = new InputStreamReader(fis,charset);		
		br = new BufferedReader(reader);
		String line = null;
		while ((line = br.readLine()) != null) {
			if (isblank(line)) {
				continue;
			}
			line = line.trim();
			list.add(line);
		}
		
		return list;
		}finally{
			close(br);
			close(fis);
			
		}
	}
	
	public static byte[] readBytes(File f) throws Exception {
		InputStream is = null;
		byte[] buf = new byte[1024];
		int num = 0;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
		try {
			is = new FileInputStream(f);
			
			while( (num = is.read(buf)) >0){
				
				bos.write(buf, 0, num);
			}

			return bos.toByteArray();

		} finally {
			close(is);
		}
	}
	
	public static byte[] readBytes(String file) throws Exception {
		return readBytes(new File(file));
	}
	
	
	public static String readString(String file,String charset) throws Exception {
	     if(isblank(charset)){
	    	 charset = CHARSET;
	     }
	     byte[] bytes = readBytes( file);
	     if(bytes==null || bytes.length <=0){
	    	 return null;
	     }
	     return new String(bytes,charset);
	}
	
	public static void write(byte[]bytes,File file) throws Exception {
		if(bytes==null || bytes.length<=0 || file==null){
			return;
		}
		OutputStream os = null;
		try {
			os = new FileOutputStream(file);
			os.write(bytes);			
		} finally {
			close(os);
		}
	}
	
	
	
	
	public static void close(Closeable obj){
		if(obj==null){
			return;
		}
		try{
		obj.close();
		}catch(Throwable e){
			
		}
	}
	
	public static List<String> split(String str,String sep){
		if(str==null){
			return null;
		}
		if(sep==null || sep.length()<1){
			return null;
		}
		List<String> list = new ArrayList<String>();
		int fromIndex = 0;
		int len = str.length();
		int sepLen = sep.length();
		int pos = 0;
		String tmp = null;
		// a,b,c
		while(true){
			
			pos = str.indexOf(sep, fromIndex);
			if(pos<0){
				list.add(str.substring(fromIndex));
				break;
			}
			//System.out.println("fromIndex="+fromIndex+",pos="+pos);
			tmp = str.substring(fromIndex, pos);
			//System.out.println("tmpstr="+tmp);
			list.add(tmp);
			
			fromIndex = fromIndex + tmp.length()+ sepLen;

		}
		
		
		
		
		return list;
	}
	
	public static String[] splitAsArray(String str,String sep){
		List<String> list = split( str, sep);
		if(list==null || list.isEmpty()){
			return null;
		}
		return ( String[] ) list.toArray();
	}
	
	public static String join(List list,String sep){
		
		if(list==null || list.isEmpty()){
			return null;
		}
		
		if(sep==null || sep.length()<1){
			sep=",";
		}
		
		StringBuilder sb = new StringBuilder();
		boolean first = true;
		for(Object item:list){
		
			if(first){
				first = false;
			}else{
				sb.append(sep);
			}
			sb.append(item);
		}
		return sb.toString();
	}
	
	public static void x()throws Exception{
		String file = "/home/gang.dug/uicdatatest.txt";
		InputStream inputStream = new FileInputStream(new File(file));
		int num = inputStream.available();
		byte[]bytes = new byte[num];
		inputStream.read(bytes);
		inputStream.close();
		String str = new String(bytes);
		String[] lines = str.split(",");
		long addrId = 0;
		long userId = 0;
		
		List<String> lineList = new ArrayList<String>();
	
	
		
		
	}

}
